import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home/Home'
import Consult from '@/components/Consult/Consult'
import Chaopeng from '@/components/Chaopeng/Chaopeng'
import My from '@/components/My/My'


// 不是必须加载的组件使用懒加载
import Examination from '@/components/Examination/Examination'
import Xiang from '@/components/Examination/Xiang'
import Personage from '@/components/Examination/Personage'
import Addxinxi from '@/components/Examination/Addxinxi'
import Team from '@/components/Examination/Team'
import AddTeamxinxi from '@/components/Examination/AddTeamxinxi'
import Zhifu from '@/components/Zhifu/Zhifu'
import Timehui from '@/components/Timehui/Timehui'
import Grxx from '@/components/Grxx/Grxx'
import Grzs from '@/components/Grxx/Grzs'
import obligation from '@/components/obligation/obligation' 
import order from '@/components/obligation/order'
import ddxiang from '@/components/obligation/ddxiang'
import ddjl from '@/components/obligation/ddjl'
import subscribe from '@/components/subscribe/subscribe'
import history from '@/components/history/history'
import orderjilu from '@/components/orderjilu/orderjilu'
import women from '@/components/women/women'
import shezhi from '@/components/shezhi/shezhi'
import login from '@/components/login/login'
import zhuce from '@/components/zhuce/zhuce'
import mima from '@/components/mima/mima'
import opinion from '@/components/opinion/opinion'
import listzx from '@/components/listzx/listzx'
import listxq from '@/components/listzx/listxq'
import paySuccess from '@/components/User/paySuccess'
import xgmm from '@/components/xgmm/xgmm'

import { Swipe, SwipeItem } from 'vant';
Vue.use(Swipe).use(SwipeItem);

import { NavBar } from 'vant';
Vue.use(NavBar);

import { Tab, Tabs } from 'vant';
Vue.use(Tab).use(Tabs);

import { Icon } from 'vant';
Vue.use(Icon);

import { RadioGroup, Radio } from 'vant';
Vue.use(RadioGroup);
Vue.use(Radio);

import { Search } from 'vant';
Vue.use(Search);

import { Picker } from 'vant';
Vue.use(Picker);

import { DatetimePicker } from 'vant';
Vue.use(DatetimePicker);

import { Step, Steps } from 'vant';
Vue.use(Step).use(Steps);

import { Checkbox, CheckboxGroup } from 'vant';
Vue.use(Checkbox).use(CheckboxGroup);

import { Popup } from 'vant';
Vue.use(Popup);
	
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
	{
	  path: '/login',
	  name: 'login',
	  component: login
	},
	{
	  path: '/consult',
	  name: 'Consult',
	  component: Consult
	},
	{
	  path: '/chaopeng',
	  name: 'Chaopeng',
	  component: Chaopeng
	},
	{
	  path: '/my',
	  name: 'My',
	  component: My
	},
	{
	  path: '/examination',
	  name: 'Examination',
	  component: resolve => require(['@/components/Examination/Examination'],resolve)
	},
	{
	  path: '/xiang',
	  name: 'Xiang',
	  component: resolve => require(['@/components/Examination/Xiang'],resolve)
	},
	{
	  path: '/personage',
	  name: 'Personage',
	  component: resolve => require(['@/components/Examination/Personage'],resolve)  
	},
	{
	  path: '/addxinxi',
	  name: 'Addxinxi',
	  component: resolve => require(['@/components/Examination/Addxinxi'],resolve) 
	},
	{
	  path: '/Team',
	  name: 'Team',
	  component: resolve => require(['@/components/Examination/Team'],resolve) 
	},
	{
	  path: '/addTeamxinxi',
	  name: 'AddTeamxinxi',
	  component: resolve => require(['@/components/Examination/AddTeamxinxi'],resolve) 
	},
	{
	  path: '/zhifu',
	  name: 'Zhifu',
	  component: resolve => require(['@/components/Zhifu/Zhifu'],resolve) 
	},
	{
	  path: '/timehui',
	  name: 'Timehui',
	  component: resolve => require(['@/components/Timehui/Timehui'],resolve) 
	},
	{
	  path: '/grxx',
	  name: 'Grxx',
	  component: resolve => require(['@/components/Grxx/Grxx'],resolve) 
	},
	{
	  path: '/grzs',
	  name: 'Grzs',
	  component: resolve => require(['@/components/Grxx/Grzs'],resolve) 
	},
	{
	  path: '/obligation',
	  name: 'obligation',
	  component: resolve => require(['@/components/obligation/obligation'],resolve) 
	},
	{
	  path: '/order',
	  name: 'order',
	  component: resolve => require(['@/components/obligation/order'],resolve) 
	},
	{
	  path: '/ddxiang',
	  name: 'ddxiang',
	  component: resolve => require(['@/components/obligation/ddxiang'],resolve) 
	},
	{
	  path: '/ddjl',
	  name: 'ddjl',
	  component: resolve => require(['@/components/obligation/ddjl'],resolve) 
	},
	{
	  path: '/subscribe',
	  name: 'subscribe',
	  component: resolve => require(['@/components/subscribe/subscribe'],resolve) 
	},
	{
	  path: '/history',
	  name: 'history',
	  component: resolve => require(['@/components/history/history'],resolve) 
	},
	{
	  path: '/orderjilu',
	  name: 'orderjilu',
	  component: resolve => require(['@/components/orderjilu/orderjilu'],resolve) 
	},
	{
	  path: '/women',
	  name: 'women',
	  component: resolve => require(['@/components/women/women'],resolve) 
	},
	{
	  path: '/shezhi',
	  name: 'shezhi',
	  component: resolve => require(['@/components/shezhi/shezhi'],resolve) 
	},
	{
	  path: '/zhuce',
	  name: 'zhuce',
	  component: resolve => require(['@/components/zhuce/zhuce'],resolve) 
	},
	{
	  path: '/mima',
	  name: 'mima',
	  component: resolve => require(['@/components/mima/mima'],resolve) 
	},
	{
	  path: '/opinion',
	  name: 'opinion',
	  component: resolve => require(['@/components/opinion/opinion'],resolve) 
	},
	{
	  path: '/listzx',
	  name: 'listzx',
	  component: resolve => require(['@/components/listzx/listzx'],resolve) 
	},
	{
	  path: '/listxq',
	  name: 'listxq',
	  component: resolve => require(['@/components/listzx/listxq'],resolve) 
	},
	{
	  path: '/user/paySuccess',
	  name: 'paySuccess',
	  component:paySuccess
	},
	{
	  path: '/xgmm',
	  name: 'xgmm',
	  component:xgmm
	}
  ]
})