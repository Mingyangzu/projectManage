<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="个人体检信息" left-arrow @click-left="onClickLeft" fixed />
		<div class="wwr">
			<van-checkbox-group v-model="result">
				<div class="sxp" v-for="(item,index) in geren" :key="index">
					<div style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;">
						<van-checkbox :name="item.id">{{item.name}}</van-checkbox>
						<div style="color:#4d83ff;">套餐类型：{{item.checkupPlanName}}</div>
					</div>
					<div v-if="item.sex==1">性别：男</div>
					<div v-if="item.sex==0">性别：女</div>
					<div style="display: flex;flex-direction: row;">
						<div>年龄：{{item.age}}</div>
						<div style="margin-left:1rem;">职业：{{item.job}}</div>
					</div>
					<div>单位名称：{{item.orgName}}</div>
					<div>身份证号：{{item.cardId}}</div>
					<div>电话：{{item.mobile}}</div>
					<div>HR联系方式：{{item.hrMobile}}</div>
					<div>通信地址：{{item.contactAddress}}</div>
					<div v-if="item.salesManId!=null">业务员ID：{{item.salesManId}}</div>
					<div class="qrd">
						<div @click="xgdd(item.id,item.checkupPlanId)">
							<img src="static/image/bianji.png" />
						</div>
						<div @click="shanchu(item.id)">
							<img src="static/image/delete.png" />
						</div>
					</div>
				</div>
			</van-checkbox-group>
		</div>
		<div class="footer">
			<div style="color:#fff;background: #3778ff;" @click="tjry">
				添加人员
			</div>
			<div style="color:#fff;background: #cb5b17;" @click="qzfk">
				去支付
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Personage",
		data() {
			return {
				result: [],
				geren: '',
				id: this.$route.query.id
			};
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			dingdanlist() {
				this.$axios.post("/user/checkupUser/readList", {
					"start": 1,
					"pageSize": 90000,
					"type": 0
				}).then((res) => {
					if(res.data.code == 0) {
						console.log(res.data.data)
						this.geren = res.data.data
					}
				})
			},
			shanchu(id) {
				this.$axios.get("/user/checkupUser/del?checkupUserId=" + id).then(res => {
					if(res.data.code == 0) {
						Toast('删除成功')
						this.dingdanlist()
					}
				})
			},
			xgdd(id,tid) {
				this.$router.push({
					name: 'Addxinxi',
					query: {
						id: id,
						tid:tid
					}
				})
			},
			tjry () {  //添加人员
				this.$router.push({
					name: 'Addxinxi',
					query: {
						tid:this.id
					}
				})
			},
			GetQueryString(name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
				var r = window.location.search.substr(1).match(reg);
				if(r != null) return unescape(r[2]);
				return null;
			},
			qzfk () { //去支付
				if(this.result==''){
					Toast('请选择要支付的订单')
				}else{
					this.$router.push({
						name: 'Zhifu',
						query: {
							result:this.result
						}
					})
				}
			}
		},
		mounted() {
			this.dingdanlist()
		}
	}
</script>

<style>
	.wwr {
		width: 100%;
		background: #fff;
		margin-bottom: 0.5rem;
	}
	
	.sxp {
		width: 90%;
		margin: 0 auto;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.sxp>div {
		padding: 0.06rem 0;
	}
	
	.qrd {
		width: 30%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-left: 70%;
	}
	
	.qrd>div {
		width: 0.25rem;
		height: 0.25rem;
	}
	
	.footer {
		width: 100%;
		height: 0.4rem;
		line-height: 0.4rem;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		position: fixed;
		bottom: 0;
	}
	
	.footer>div {
		width: 50%;
		text-align: center;
		color: #fff;
	}
</style>