<template>
	<div>
		<van-nav-bar title="设置" left-arrow @click-left="onClickLeft" fixed />
		<div style="background: #fff;margin-top:0.46rem;">
			<router-link class="fankui" style="border-bottom:1px solid #e5e5e5;" :to="{name:'opinion'}">
				<div>意见反馈</div>
				<div>
					<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
				</div>
			</router-link>
			<router-link class="fankui" :to="{name:'xgmm'}">
				<div>修改密码</div>
				<div>
					<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
				</div>
			</router-link>
		</div>
		<button class="tuichu" @click="tuichu" disabled="disabled" v-show="disabled">退出当前账号</button>
		<button class="zhanghao" @click="tuichu" v-show="!disabled">退出当前账号</button>
	</div>
</template>

<script>
	import { Toast } from 'vant'
	export default {
		name: "shezhi",
		data() {
			return {
				disabled: true
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			tuichu() {
				this.$axios.get("/user/logout").then((res) => {
					if(res.data.code == 0) {
						Toast('退出成功')
						localStorage.removeItem("phone")
						this.$router.push({
							name: 'Home'
						})
					}
				})
			}
		},
		mounted() {
			if(localStorage.getItem("phone")) {
				this.disabled = false;
			} else {
				this.disabled = true;
			}
		}
	}
</script>

<style>
	.fankui {
		width: 90%;
		display: flex;
		;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.15rem 0;
		margin: 0 auto;
		color: #323232;
	}
	
	.zhanghao {
		width: 90%;
		margin: 2rem 5%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		text-align: center;
		border-radius: 0.3rem;
		background: #057BE3;
		border: none;
	}
	
	.tuichu {
		width: 90%;
		margin: 2rem 5%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #ccc;
		text-align: center;
		border-radius: 0.3rem;
		background: #999999;
		border: none;
	}
</style>