<template>
	<div class="can">
		<div class="nian">年度套餐</div>
		<div class="tao">
			<a @click="taocan(1)" style="width:50%;">
				<img src="static/image/setMeal_01.png" style="width:100%;height:100%;" />
			</a>
			<div class="azm">
				<a @click="taocan(2)" style="height:0.55rem">
					<img src="static/image/setMeal_02.png" style="width:100%;height:100%;" />
				</a>
				<a @click="taocan(3)" style="height:0.55rem">
					<img src="static/image/setMeal_03.png" style="width:100%;height:100%;" />
				</a>
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Taocan",
		data() {
			return {
				list: ''
			}
		},
		methods:{
			taocan (id) {
				sessionStorage.setItem("id", id);
				this.$router.push({name:'Xiang'})
			}
		}
	}
</script>

<style>
	.can {
		width: 100%;
		background: #fff;
		margin: 0.05rem 0;
	}
	
	.nian {
		position: relative;
		width: 90%;
		left: 5%;
		padding: 0.05rem 0 0;
	}
	
	.tao {
		width: 90%;
		height: 1.15rem;
		padding: 0.1rem 0;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}
	
	.azm {
		width: 49%;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		align-items: center;
	}
</style>