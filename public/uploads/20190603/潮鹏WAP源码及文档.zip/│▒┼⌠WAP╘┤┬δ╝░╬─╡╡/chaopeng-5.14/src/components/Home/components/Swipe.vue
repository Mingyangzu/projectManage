<template>
	<div>
		<van-swipe :autoplay="5000">
			<van-swipe-item v-for="(image, index) in images" :key="index">
				<img v-lazy="image" style="width:100%;height:100%;"/>
			</van-swipe-item>
		</van-swipe>
	</div>
</template>

<script>
	export default {
		name: "Swipe",
		data() {
			return {
				images: [
					'static/image/banner_01.png',
					'static/image/banner_02.png',
					'static/image/banner_03.png'
				]
			}
		}
	}
</script>

<style>
	.van-swipe__track{
		height:2rem;
		margin-top:0.4rem;
	}
</style>
