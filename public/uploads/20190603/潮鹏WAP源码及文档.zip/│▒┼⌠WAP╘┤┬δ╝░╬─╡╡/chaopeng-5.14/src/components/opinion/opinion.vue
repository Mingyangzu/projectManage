<template>
	<div style="margin-top:0.4rem;background:#fff;">
		<van-nav-bar title="意见反馈" left-arrow @click-left="onClickLeft" fixed />
		<div style="padding:0.2rem 0;">
			<van-radio-group v-model="radio">
			  <van-radio name="账号">账号</van-radio>
			  <van-radio name="预约">预约</van-radio>
			  <van-radio name="购买">购买</van-radio>
			  <van-radio name="其他">其他</van-radio>
			</van-radio-group>
		</div>
		<div class="svy">
			<textarea placeholder="请输入反馈意见,50字以内" maxlength="50" v-model="yijian" style="width:88%;border:none;height:2rem;padding:0.1rem 0.2rem;"></textarea>
		</div>
		<div class="lianxi"><input placeholder="请输入联系方式" style="border:none;height:0.4rem;margin-left:5%;" v-model="phonea" /></div>
		<div class="nbv" @click="fankui">提交</div>
	</div>
</template>

<script>
	import {
		Toast
	} from 'vant';
	export default {
		name: 'opinion',
		data() {
			return {
				radio:'账号',
				yijian: '',
				phonea:''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			urlencode (str) {  
				str = (str + '').toString();   
				return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
				replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');  
			},
			fankui() {
				if(this.yijian==''){
					Toast('请输入反馈意见')
				}else{
					this.$axios.post("/user/opinion/add", {
						"content": this.yijian,
						"contactMobile":this.phonea,
						"opinionType":this.urlencode(this.radio)
					}).then((res) => {
						if (res.data.code == 0) {
							Toast('反馈成功')
							this.yijian = '';
							this.phonea = '';
							setTimeout( res => {
								this.$router.push({name:'My'})
							},1000)
						}else{
							Toast(res.data.msg)
						}
					})
				}
			}
		}
	}
</script>

<style>
	.svy {
		width: 90%;
		margin: 0 auto;
		padding: 0.02rem 0;
		border: 0.01rem solid #ccc;
		border-radius: 0.05rem;
	}

	.nbv {
		width: 90%;
		margin: 1rem auto;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		text-align: center;
		background: #3778ff;
		border-radius: 0.3rem;
	}
	.van-radio-group{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		text-align: center;
	}
	.van-radio{
		width:25%;
	}
	.lianxi{
		width:90%;
		margin:0.2rem auto;
		height:0.4rem;
		border:0.01rem solid #ccc;
		border-radius: 0.1rem;
	}
</style>
