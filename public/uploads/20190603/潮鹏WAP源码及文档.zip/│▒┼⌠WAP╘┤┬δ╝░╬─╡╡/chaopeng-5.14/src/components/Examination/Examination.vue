<template>
	<div>
		<van-nav-bar title="体检项目" left-arrow @click-left="onClickLeft" fixed />
		<div class="tab">
			<div class="tab-tit">
				<div @click="tabs(1)" :class="{'cur':msg==1}">常规体检</div>
				<div @click="tabs(2)" :class="{'cur':msg==2}">入职体检</div>
				<div @click="tabs(3)" :class="{'cur':msg==3}">职业病体检</div>
				<div @click="tabs(4)" :class="{'cur':msg==4}">健康证体检</div>
			</div>
			<div class="tab-con">
				<div v-show="msg==1">
					<div class="wsu" @click="sfcv(item.id)" v-for="(item,index) in list" :key="index">
						<div class="tut">
							<img :src="http+item.smallPicUrl" style="width:100%;height:100%;" />
						</div>
						<div class="qing">
							<div style="color:#494949;font-size:0.16rem;">{{item.name}}</div>
							<div class="ziz">{{item.details}}</div>
							<div class="money">
								<div style="color:#ff0000;font-size:0.16rem;">￥{{item.price}}起</div>
							</div>
						</div>
					</div>
				</div>
				<div v-show="msg==2">
					<div class="wsu" @click="sfcv(item.id)" v-for="(item,index) in list" :key="index">
						<div class="tut">
							<img :src="http+item.smallPicUrl" style="width:100%;height:100%;" />
						</div>
						<div class="qing">
							<div style="color:#494949;font-size:0.16rem;">{{item.name}}</div>
							<div class="ziz">{{item.details}}</div>
							<div class="money">
								<div style="color:#ff0000;font-size:0.16rem;">￥{{item.price}}起</div>
							</div>
						</div>
					</div>
				</div>
				<div v-show="msg==3">
					<div class="wsu" @click="sfcv(item.id)" v-for="(item,index) in list" :key="index">
						<div class="tut">
							<img :src="http+item.smallPicUrl" style="width:100%;height:100%;" />
						</div>
						<div class="qing">
							<div style="color:#494949;font-size:0.16rem;">{{item.name}}</div>
							<div class="ziz">{{item.details}}</div>
							<div class="money">
								<div style="color:#ff0000;font-size:0.16rem;">￥{{item.price}}起</div>
							</div>
						</div>
					</div>
				</div>
				<div v-show="msg==4">
					<div class="wsu" @click="sfcv(item.id)" v-for="(item,index) in list" :key="index">
						<div class="tut">
							<img :src="http+item.smallPicUrl" style="width:100%;height:100%;" />
						</div>
						<div class="qing">
							<div style="color:#494949;font-size:0.16rem;">{{item.name}}</div>
							<div class="ziz">{{item.details}}</div>
							<div class="money">
								<div style="color:#ff0000;font-size:0.16rem;">￥{{item.price}}起</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Examination",
		data() {
			return {
				http: 'https://www.chaopengjiankang.com/api',
				msg: 1,
				list: '',
				paixu: 0
			}
		},
		methods: {
			onClickLeft() {
				var ua = navigator.userAgent.toLowerCase();
			    if (ua.match(/MicroMessenger/i) == "micromessenger") {
			    	this.$router.push({
						name: 'Home'
					})
			    }else{
			    	this.$router.go(-1);
			    }
			},
			sfcv(id) {
				sessionStorage.setItem("id", id);
				this.$router.push({
					name: 'Xiang'
				})
			},
			tabs(index) {
				this.msg = index;
				this.$axios.post("/checkupPlan/readList", {
					"start": 1,
					"pageSize": 1000,
					"typeId": this.msg,
					"orderType": this.paixu
				}).then((res) => {
					if(res.data.code == 0) {
						console.log(res.data.data)
						this.list = res.data.data;
					}
				})
			}
		},
		mounted() {
			var _this=this;
			var value,name;
			var str = location.href;
			var num = str.indexOf("?");
			str = str.substr(num + 1); 
			var arr = str.split("&"); 
			for(let i = 0; i < arr.length; i++) {
				num = arr[i].indexOf("=");
				if(num > 0) {
					name = arr[i].substring(0, num);
					value = arr[i].substr(num + 1);
					_this[name] = value;
				}
			}
			if(sessionStorage.getItem("tijian") && !value){
				_this.msg = Number(sessionStorage.getItem("tijian"))
				_this.$axios.post("/checkupPlan/readList", {
					"start": 1,
					"pageSize": 1000,
					"typeId": _this.msg,
					"orderType": _this.paixu
				}).then((res) => {
					if(res.data.code == 0) {
						_this.list = res.data.data;
					} else if(res.data.code == 501) {
						_this.$router.push({
							name: 'login'
						})
					}
				})
			}else{
				_this.msg = value;
				_this.$axios.post("/checkupPlan/readList", {
					"start": 1,
					"pageSize": 1000,
					"typeId": _this.msg,
					"orderType": _this.paixu
				}).then((res) => {
					if(res.data.code == 0) {
						_this.list = res.data.data;
					} else if(res.data.code == 501) {
						_this.$router.push({
							name: 'login'
						})
					}
				})
			}
		}
	}
</script>

<style>
	.tab-tit {
		width: 100%;
		color: #000;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		background: #fff;
		position: fixed;
		top: 0.46rem;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.tab-tit div {
		height: 0.4rem;
		line-height: 0.4rem;
		width: 25%;
		text-align: center;
	}
	
	.tab-tit .cur {
		color: #3778ff;
	}
	
	.tab-con {
		position: relative;
		top: 0.89rem;
		background: #fff;
	}
	
	.van-tabs__line {
		height: 0;
		background: #fff;
	}
	
	.wsu {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		border-bottom: 0.01rem solid #e5e5e5;
		padding: 0.1rem 0;
	}
	
	.tut {
		width: 40%;
		height: 1rem;
	}
	
	.qing {
		width: 55%;
	}
	
	.money {
		display: flex;
		flex-direction: row;
		;
		justify-content: space-between;
	}
	
	.ziz {
		color: #999999;
		margin: 0.1rem 0;
		width: 100%;
		word-break: break-all;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		overflow: hidden;
	}
	
	.biao {
		display: inline-block;
		width: 0.12rem;
		height: 0.12rem;
	}
</style>