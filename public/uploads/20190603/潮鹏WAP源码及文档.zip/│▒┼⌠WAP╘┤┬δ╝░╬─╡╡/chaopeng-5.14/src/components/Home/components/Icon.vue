<template>
	<div class="icon">
		<a @click="tjtc(1)">
			<div class="tuu">
				<img src="static/image/bar_icon_04.png" class="img" />
			</div>
			<div style="color:#000;">常规体检</div>
		</a>
		<a @click="tjtc(2)">
			<div class="tuu">
				<img src="static/image/bar_icon_03.png" class="img" />
			</div>
			<div style="color:#000;">入职体检</div>
		</a>
		<a @click="tjtc(3)">
			<div class="tuu">
				<img src="static/image/bar_icon_01.png" class="img" />
			</div>
			<div style="color:#000;">职业病体检</div>
		</a>
		<a @click="tjtc(4)">
			<div class="tuu">
				<img src="static/image/bar_icon_05.png" class="img" />
			</div>
			<div style="color:#000;">健康证体检</div>
		</a>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Icon",
		methods:{
			tjtc (msg) {
				sessionStorage.setItem("tijian", msg);
				this.$router.push({name:'Examination'})
			}
		}
	}
</script>

<style>
	.icon {
		width: 100%;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
		font-size: 0.14rem;
		background: #fff;
	}
	
	.icon a {
		width: 25%;
		text-align: center;
		padding: 0.05rem 0;
	}
	
	.tuu {
		width: 0.5rem;
		height: 0.5rem;
		margin: 0.02rem auto;
	}
	
	.img {
		width: 100%;
		height: 100%;
	}
</style>