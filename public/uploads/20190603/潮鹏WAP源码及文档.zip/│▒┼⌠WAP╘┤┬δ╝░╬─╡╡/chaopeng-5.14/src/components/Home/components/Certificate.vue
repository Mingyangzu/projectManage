<template>
	<div class="zheng" @click="jiankang">
		<div class="jiankang">
			<img src="static/image/card_01.png" style="width:100%;height:100%;" />
		</div>
	</div>
</template>

<script>
	export default {
		name: "Certificate",
		methods : {
			jiankang (){
				sessionStorage.setItem("tijian", 4);
				this.$router.push({name:'Examination'})
			}
		}
	}
</script>

<style>
	.zheng{
		width:100%;
		background: #fff;
		margin:0.05rem 0;
	}
	.jiankang{
		width:90%;
		height:1.5rem;
		padding:0.1rem 0;
		margin:0 auto;
	}
</style>
