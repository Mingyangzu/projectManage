<template>
	<div>
		<van-nav-bar title="限时特惠" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;background: #fff;">
			<div v-for="(can,index) in items" :key="index">
				<router-link :to="{name:'Xiang'}" class="wsu">
					<div class="tut">
						<img :src="can.img" style="width:100%;height:100%;" />
					</div>
					<div class="qing">
						<div style="color:#494949;font-size:0.16rem;">{{can.name}}</div>
						<div class="ziz">{{can.jianjie}}</div>
						<div style="width:50%;">
							<div style="color:#ff0000;font-size:0.16rem;">￥{{can.money}}起</div>
						</div>
					</div>
				</router-link>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Timehui",
		data() {
			return {
				items: [{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
					{
						name: "优惠特价活动",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "566.00",
						peop: "2306"
					},
				]
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			}
		}
	}
</script>

<style>

</style>
