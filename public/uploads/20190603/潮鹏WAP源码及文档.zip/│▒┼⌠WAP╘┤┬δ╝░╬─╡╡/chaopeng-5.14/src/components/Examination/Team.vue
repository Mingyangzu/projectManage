<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="团队体检信息" left-arrow @click-left="onClickLeft" fixed />
		<div class="wwr">
			<van-checkbox-group v-model="result">
				<div class="sxp" v-for="(item,index) in tuanti" :key="index">
					<div style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;">
						<van-checkbox :name="item.id">{{item.orgName}}</van-checkbox>
						<div style="color:#4d83ff;">套餐类型：{{item.checkupPlanName}}</div>
					</div>
					<div>体检人数：{{item.checkNum}}</div>
					<div>电话：{{item.mobile}}</div>
					<div>HR联系方式：{{item.hrMobile}}</div>
					<div>E-mail：{{item.email}}</div>
					<div>单位地址：{{item.contactAddress}}</div>
					<div v-if="item.salesManId!=null">业务员ID：{{item.salesManId}}</div>
					<div class="tre">
						<div @click="tuduix(item.id,item.checkupPlanId)">
							<img src="static/image/bianji.png" />
						</div>
						<div @click="deletes(item.id)">
							<img src="static/image/delete.png" />
						</div>
					</div>
				</div>
			</van-checkbox-group>
		</div>
		<div class="footer">
			<div @click="tjtdd" style="color:#fff;background: #3778ff;">
				添加团队
			</div>
			<div @click="tdzf" style="color:#fff;background: #cb5b17;">
				去支付
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Team",
		data() {
			return {
				result: [],
				tuanti: ''
			};
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			tuanlist() {
				this.$axios.post("/user/checkupUser/readList", {
					"start": 1,
					"pageSize": 100000,
					"type": 1,
				}).then((res) => {
					console.log(res.data.data)
					if(res.data.code == 0) {
						this.tuanti = res.data.data
					}
				})
			},
			deletes(id) { //删除
				this.$axios.get("/user/checkupUser/del?checkupUserId=" + id).then(res => {
					if(res.data.code == 0) {
						Toast('删除成功')
						this.tuanlist()
					}
				})
			},
			tjtdd () {  //添加团队
				console.log(this.$route.query.id)
				this.$router.push({name:'AddTeamxinxi',query:{tid:this.$route.query.id}})
			},
			GetQueryString(name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
				var r = window.location.search.substr(1).match(reg);
				if(r != null) return unescape(r[2]);
				return null;
			},
			tdzf () { //去支付
				if(this.result==''){
					Toast('请选择要支付的订单')
				}else{
					this.$router.push({
						name: 'Zhifu',
						query: {
							result:this.result
						}
					})
				}
			},
			tuduix(id,tid) {  //修改
				this.$router.push({
					name: 'AddTeamxinxi',
					query: {
						id: id,
						tid:tid
					}
				})
			}
		},
		mounted() {
			this.tuanlist()
		}
	}
</script>

<style>
	.wwr {
		width: 100%;
		background: #fff;
		margin-bottom: 0.5rem;
	}
	
	.sxp {
		width: 90%;
		margin: 0 auto;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.sxp>div {
		padding: 0.06rem 0;
	}
	
	.tre {
		width: 30%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-left: 70%;
	}
	
	.tre>div {
		width: 0.25rem;
		height: 0.25rem;
	}
	
	.footer {
		width: 100%;
		height: 0.4rem;
		line-height: 0.4rem;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		position: fixed;
		bottom: 0;
	}
	
	.footer>div {
		width: 50%;
		text-align: center;
		color: #fff;
	}
</style>