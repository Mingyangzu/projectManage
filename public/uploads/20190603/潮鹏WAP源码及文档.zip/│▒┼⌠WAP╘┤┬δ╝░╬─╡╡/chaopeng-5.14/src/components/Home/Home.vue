<template>
	<div class="cvb">
		<Header></Header>
		<Swipe></Swipe>
		<Icon></Icon>
		<Certificate></Certificate>
		<Taocan></Taocan>
		<Shouhou></Shouhou>
		<Tehui></Tehui>
		<Zixun></Zixun>
		<div class="snbr">Copyrigt @ 2019-2020 潮鹏管理 版权所有京ICP备16051221号</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Footer from '@/components/Footer/Footer'
	import Header from './components/Header'
	import Swipe from './components/Swipe'
	import Icon from './components/Icon'
	import Certificate from './components/Certificate'
	import Taocan from './components/Taocan'
	import Shouhou from './components/Shouhou'
	import Tehui from './components/Tehui'
	import Zixun from './components/Zixun'
	export default {
		name: "Home",
		components: {
			Footer,
			Header,
			Swipe,
			Icon,
			Certificate,
			Taocan,
			Shouhou,
			Tehui,
			Zixun
		}
	}
</script>

<style>
	.cvb {
		background: #e5e5e5;
		margin-bottom: 0.5rem;
	}
	.snbr{
		font-size:0.10rem;
		width:85%;
		text-align: center;
		color:#999999;
		padding:0.15rem 0;
		margin:0 auto;
	}
</style>