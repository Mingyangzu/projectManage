<template>
	<div>
		<van-nav-bar title="人员信息" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;">
			<div style="background: #fff;">
				<div class="lei">
					<div class="xvb">姓名</div>
					<div><input placeholder="输入真实姓名" class="wed" v-model="xing1" /></div>
				</div>
				<div class="lei">
					<div class="xvb">性别</div>
					<van-radio-group v-model="radio" class="radio">
						<van-radio name="1">男</van-radio>
						<van-radio name="0">女</van-radio>
					</van-radio-group>
				</div>
				<div class="lei">
					<div class="xvb">年龄</div>
					<div><input placeholder="输入年龄" class="wed" v-model="ling" /></div>
				</div>
				<div class="lei" @click="taocan">
					<div class="xvb">体检套餐</div>
					<div>{{lei}}</div>
				</div>
				<div class="lei">
					<div class="xvb">职业</div>
					<div><input placeholder="输入职业" class="wed" v-model="zhiye" /></div>
				</div>
				<div class="lei">
					<div class="xvb">电话号码</div>
					<div><input placeholder="输入电话号码" type="number" class="wed" v-model="haoma" /></div>
				</div>
				<div class="lei">
					<div class="xvb">身份证号</div>
					<div><input placeholder="输入身份证号" class="wed" v-model="shenfen" /></div>
				</div>
				<div class="lei">
					<div class="xvb">单位名称</div>
					<div><input placeholder="输入单位名称" class="wed" v-model="danwei" /></div>
				</div>
				<div class="lei">
					<div class="xvb">HR联系方式</div>
					<div><input placeholder="非必填" type="number" class="wed" v-model="phoneHR" /></div>
				</div>
				<div class="lei">
					<div class="xvb">业务员ID</div>
					<div><input placeholder="非必填" type="text" class="wed" v-model="ywy" /></div>
				</div>
				<div class="address">
					<div>通讯地址</div>
					<div><input placeholder="例：北京市朝阳区立水桥北8号" class="inpt" v-model="dizhi" /></div>
				</div>
			</div>
		</div>
		<van-popup v-model="can" position="bottom" :overlay="true" :close-on-click-overlay="true">
			<van-picker show-toolbar title="套餐选择" :default-index="xuanzhong" :columns="columns" @cancel="onCancel" @confirm="onConfirm" @change="onchange" />
		</van-popup>
		<div class="queren" @click="wocao" v-if="xinxid==''">保存</div>
		<div class="queren" @click="xiuaiy" v-if="xinxid!=''">修改</div>
	</div>
</template>

<script>
	var myreg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
	var idcardReg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
	import { Toast } from 'vant';
	export default {
		name: "Addxinxi",
		data() {
			return {
				radio: '1',
				can: false,
				xing1: '',
				ling: '',
				zhiye: '',
				haoma: '',
				shenfen: '',
				danwei: '',
				dizhi: '',
				ywy: '',
				phoneHR:'',
				lei: '请选择',
				columns: [],
				id:'',
				xinxid: '',
				xuanzhong:0
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			taocan() {
				this.can = true;
			},
			onchange (picker, values) {
				var getIndexes=picker.getIndexes(1);
				console.log(getIndexes)
				this.$axios.post("/checkupPlan/readList", {
					"start": 1,
					"pageSize": 100000,
					"orderType": 1,
				}).then(res => {
					if(res.data.code == 0) {
						var taocan = res.data.data;
						var first={};
						first.id=null;
						first.name='请选择';
						taocan.unshift(first);
						console.log(taocan[getIndexes[0]].id)
						this.id=taocan[getIndexes[0]].id;
					}
				})
			},
			onCancel() {
				this.can = false;
			},
			onConfirm(value, index) {
				this.can = false;
				this.lei = value;
			},
			wocao() { //添加
				if(this.xing1 == '') {
					Toast('请输入真实姓名')
				} else if(this.ling == '') {
					Toast('请输入年龄')
				} else if(this.zhiye == '') {
					Toast('请输入职业')
				} else if(myreg.test(this.haoma)) {
					if(idcardReg.test(this.shenfen)) {
						if(this.danwei == '') {
							Toast('请输入单位名称')
						} else if(this.dizhi == '') {
							Toast('请输入通讯地址')
						} else if(this.lei == '请选择') {
							Toast('请选择体检套餐')
						} else {
							this.$axios.post("/user/checkupUser/addSingle", {
								"name": this.xing1,
								"sex": this.radio,
								"age": this.ling,
								"job": this.zhiye,
								"checkupPlanId": this.id,
								"cardId": this.shenfen,
								"mobile": this.haoma,
								"orgName": this.danwei,
								"contactAddress": this.dizhi,
								"hrMobile":this.phoneHR,
								"salesManId": this.ywy
							}).then((res) => {
								if(res.data.code == 0) {
									Toast('添加成功')
									this.$router.push({
										name: 'Personage'
									})
								}else{
									Toast(res.data.msg)
								}
							})
						}
					} else {
						Toast('请输入正确身份证号')
					}
				} else {
					Toast('请输入正确手机号')
				}
			},
			xiuaiy() { //修改
				if(this.xing1 == '') {
					Toast('请输入真实姓名')
				} else if(this.ling == '') {
					Toast('请输入年龄')
				} else if(this.zhiye == '') {
					Toast('请输入职业')
				} else if(myreg.test(this.haoma)) {
					if(idcardReg.test(this.shenfen)) {
						if(this.danwei == '') {
							Toast('请输入单位名称')
						} else if(this.dizhi == '') {
							Toast('请输入通讯地址')
						} else if(this.lei == '请选择') {
							Toast('请选择体检套餐')
						} else {
							this.$axios.post("/user/checkupUser/modifySingleInfo", {
								"id": this.$route.query.id,
								"name": this.xing1,
								"sex": this.radio,
								"age": this.ling,
								"job": this.zhiye,
								"checkupPlanId": this.id,
								"cardId": this.shenfen,
								"mobile": this.haoma,
								"orgName": this.danwei,
								"contactAddress": this.dizhi,
								"hrMobile":this.phoneHR,
								"salesManId": this.ywy
							}).then(res => {
								if(res.data.code == 0) {
									Toast('修改成功')
									this.$router.push({
										name: 'Personage'
									})
								}
							})
						}
					} else {
						Toast('请输入正确身份证号')
					}
				} else {
					Toast('请输入正确手机号')
				}
			}
		},
		mounted() {
			this.$axios.post("/checkupPlan/readList", {
				"start": 1,
				"pageSize": 100000,
				"orderType": 1,
			}).then(res => {
				if(res.data.code == 0) {
					var taocan = res.data.data;
					var first={};
					first.id=null;
					first.name='请选择';
					taocan.unshift(first);
					console.log(taocan)
					for(var i = 0; i < taocan.length; i++) {
						this.columns.push(taocan[i].name)
						if(this.$route.query.tid) {
							this.id=this.$route.query.tid;
							if(taocan[i].id==this.$route.query.tid){
								this.xuanzhong=i
								this.lei=taocan[i].name
							}
						}
					}
				}
			})
			if(this.$route.query.id) { //获取指定个人信息
				this.xinxid = this.$route.query.id
				this.$axios.get("/user/checkupUser/querySingleInfo?checkupUserId=" + this.$route.query.id).then((res) => {
					if(res.data.code == 0) {
						var grxx = res.data.data;
						this.xing1 = grxx.name;
						this.ling = grxx.age;
						this.zhiye = grxx.job;
						this.haoma = grxx.mobile;
						this.shenfen = grxx.cardId;
						this.danwei = grxx.orgName;
						this.dizhi = grxx.contactAddress;
						this.radio = JSON.stringify(grxx.sex);
						this.ywy = grxx.salesManId;
						this.phoneHR=grxx.hrMobile;
					}
				})
			}
		}
	}
</script>

<style>
	.lei {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		align-items: center;
		padding: 0.15rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.wed {
		border: none;
	}
	
	.xvb {
		width: 0.6rem;
		margin-right:13%;
	}
	
	.radio {
		width:60%;
		display: flex;
		flex-direction: row;
	}

	
	.address {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		padding: 0.15rem 0;
	}
	
	.inpt {
		margin-left: 0;
		padding: 0.2rem 0;
		width: 80%;
		border: none;
	}
	
	.queren {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		border-radius: 0.3rem;
		text-align: center;
		background: #3778ff;
		margin: 0.05rem auto;
	}
</style>