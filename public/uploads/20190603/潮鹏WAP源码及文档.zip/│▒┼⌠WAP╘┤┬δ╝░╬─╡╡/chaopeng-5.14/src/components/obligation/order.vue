<template>
	<div style="margin:0.46rem 0 0.6rem;">
		<van-nav-bar title="订单详情" left-arrow @click-left="onClickLeft" fixed />
		<div style="background: #fff;margin-bottom:0.04rem;">
			<div class="gou">
				<div class="xinxi">个人购买</div>
				<div class="qsc">
					<div class="tut">
						<img src="static/image/xiang.png" style="width:100%;height:100%;" />
					</div>
					<div class="qing">
						<div style="color:#494949;font-size:0.16rem;">体检套餐A</div>
						<div class="ziz">健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验</div>
						<div class="money">
							<div style="color:#ff0000;font-size:0.16rem;">￥566.00起</div>
							<div style="color:#999999;">X1</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="ding">
			<div style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;">
				<div style="font-size:0.18rem;color:#000;">订单信息</div>
				<div>电话:152****6523</div>
			</div>
			<div>
				<div>张三</div>
				<div>身份证:610*****5262</div>
			</div>
			<div>
				<div>张三</div>
				<div>身份证:610*****5262</div>
			</div>
			<div>
				<div>张三</div>
				<div>身份证:610*****5262</div>
			</div>
			<div>
				<div>张三</div>
				<div>身份证:610*****5262</div>
			</div>
			<div>
				<div>张三</div>
				<div>身份证:610*****5262</div>
			</div>
		</div>
		<div class="ecg">
			<div>
				<div>创建时间:</div>
				<div>2019-03-27</div>
			</div>
			<div>
				<div>订单编号:</div>
				<div>5454165464</div>
			</div>
			<div>
				<div>总计:</div>
				<div>￥288.00</div>
			</div>
		</div>
		<div class="moneg">
			<div class="you">
				<div class="quxiao" style="margin-right:0.15rem;">取消订单</div>
				<div class="fukuan">
					<router-link :to="{name:'Zhifu'}" style="color:#fff;">
						去付款
					</router-link>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name:"order",
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			}
		}
	}
</script>

<style>
	.gou {
		width: 90%;
		margin:0 auto;
	
	}
	
	.xinxi {
		padding: 0.1rem 0;
		color:#999999;
	}
	
	.qsc {
		width: 100%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.1rem 0;
	}
	
	.tut {
		width: 40%;
		height: 1rem;
	}
	
	.qing {
		width: 55%;
	}
	
	.money {
		display: flex;
		flex-direction: row;
		;
		justify-content: space-between;
	}
	
	.ziz {
		color: #999999;
		margin: 0.1rem 0;
		width: 100%;
		word-break: break-all;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		overflow: hidden;
	}
	.ding{
		width:90%;
		margin:0 auto;
		background: #fff;
		padding:0.1rem;
	}
	.ding>div{
		border-bottom:0.01rem solid #e5e5e5;
		padding:0.1rem 0;
		line-height: 0.25rem;
		color:#7d7d7d;
	}
	.ecg{
		width:90%;
		margin:0.05rem auto;
		background: #fff;
		padding:0.1rem;
	}
	.ecg>div{
		padding:0.03rem 0;
		line-height: 0.25rem;
		color:#7d7d7d;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}
	.quxiao{
		border:0.01rem solid #e5e5e5;
		padding:0.05rem 0.1rem;
		border-radius: 0.03rem;
		color:#757575;
	}
	.fukuan{
		background: #3778ff;
		padding:0.05rem 0.2rem;
		border-radius: 0.03rem;
		color:#fff;
	}
	.moneg{
		width:100%;
		height:0.5rem;
		background: #FFFFFF;
		position: fixed;
		bottom:0;
	}
	.you{
		width:90%;
		height:0.5rem;
		display: flex;
		flex-direction: row;
		justify-content: flex-end;
		align-items: center;
	}
</style>
