<template>
	<div>
		<div class="header1">
			<div class="deng1">
				<router-link :to="{name:'login'}" style="color:#fff;" v-if="show3==501">
					登录
				</router-link>
			</div>
			<div class="logo1">
				<img src="static/image/logo.png" style="width:100%;height:100%;" />
			</div>
			<div class="san1"></div>
		</div>
		<!--<div class="peng">
			<van-search v-model="value" placeholder="手机号查询" show-action shape="round" @search="onSearch">
				<div slot="action" @click="onSearch">搜索</div>
			</van-search>
		</div>
		<div class="nei">
			<div class="bing">
				<div v-for="(item,index) in items" :key="index">
					<div style="width:100%;height:1.7rem;">
						<img v-image-preview :src="item.img"/>
					</div>
					<div style="font-size:0.16rem;">{{item.name}}</div>
					<div style="color:#999999;">手机号码:{{item.phone}}</div>
					<div style="color:#999999;">{{item.day}}</div>
				</div>
			</div>
		</div>-->
		<div class="cang" v-if="cang==0">
			<div class="yin">
				<img src="static/image/yincang.png" />
			</div>
			<div style="margin:0.08rem 0;color:#999999;font-size:0.16rem;">暂未开放，敬请期待</div>
		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Footer from '@/components/Footer/Footer'
	export default {
		name: "Chaopeng",
		data() {
			return {
				cang:0,
				value:'',
				show3:'',
				items: [{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					},
					{
						name: '张三',
						img: 'static/image/consult.png',
						phone: '152****5265',
						day: '2019-3-25'
					}
				]
			}
		},
		methods:{
			onSearch () {
				
			}
		},
		components: {
			Footer
		},
		mounted() {
			
		}
	}
</script>

<style>
	.van-search__content--round{
		border:0.01rem solid #e5e5e5;
	}
	.peng {
		background: #fff;
		margin-top: 0.46rem;
	}
	
	.chaxun {
		width: 90%;
		padding: 0.15rem 0;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}
	
	.tgp {
		width: 100%;
		height: 0.3rem;
		padding-left: 0.06rem;
		border: 0.01rem solid #e5e5e5;
		border-radius: 0.05rem;
	}
	
	.xun {
		width: 1rem;
		height: 0.35rem;
		line-height: 0.35rem;
		text-align: center;
		background: #3778ff;
		color: #fff;
		border-radius: 0.3rem;
	}
	
	::-webkit-input-placeholder {
		margin-left: 0.05rem;
	}
	
	.nei {
		width: 100%;
		background: #fff;
		margin-top: 0.05rem;
		margin-bottom: 0.5rem;
	}
	
	.bing {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
		padding: 0.03rem 0;
	}
	
	.bing>div {
		width: 45%;
		border: 0.01rem solid #e5e5e5;
		margin: 0.03rem 0;
		padding: 0.05rem;
		line-height: 0.25rem;
	}
	
	.cang {
		width: 100%;
		height: 4rem;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	
	.yin {
		width: 1.1rem;
		height: 1rem;
	}
</style>