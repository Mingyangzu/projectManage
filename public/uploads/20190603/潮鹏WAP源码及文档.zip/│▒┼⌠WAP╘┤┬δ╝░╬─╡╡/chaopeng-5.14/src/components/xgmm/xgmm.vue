<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="修改密码" left-arrow @click-left="onClickLeft" fixed />
		<div class="askfdj">
			<div>
				<div class="scy">
					<img src="static/image/suo.png" />
				</div>
				<div class="inbf">
					<input placeholder="请输入原密码" :type="type" style="border:none;height:0.4rem;" v-model="qsrmm" />
				</div>
			</div>
			<div>
				<div class="scy">
					<img src="static/image/suo.png" />
				</div>
				<div class="inbf">
					<input placeholder="请输入新密码" :type="type" style="border:none;height:0.4rem;" v-model="passgh" />
				</div>
			</div>
			<div>
				<div class="scy">
					<img src="static/image/suo.png" />
				</div>
				<div class="inbf">
					<input placeholder="确认新密码" :type="type" style="border:none;height:0.4rem;" v-model="xmm" />
				</div>
			</div>
		</div>
		<div class="dfgd" @click="queren">提交</div>
	</div>
</template>

<script>
	import { Toast } from 'vant'
	export default {
		name: 'xgmm',
		data() {
			return {
				type: "password",
				qsrmm: '',
				passgh: '',
				xmm: ''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			queren() {
				if(this.qsrmm == '' && this.qsrmm.length > 6 && this.qsrmm.length < 12) {
					Toast('请输入原密码长度为6-12位字符');
				} else if(this.passgh == '' && this.passgh.length > 6 && this.passgh.length < 12) {
					Toast('请输入新密码长度为6-12位字符');
				} else if(this.xmm != this.passgh) {
					Toast('两次密码不一致');
				} else {
					this.$axios.post("/user/modifyPassword", {
						"oldPassword": this.qsrmm,
						"newPassword": this.passgh,
						"confirmPassword":this.xmm
					}).then((res) => {
						console.log(res.data)
						if (res.data.code == 0) {
							this.$axios.get("/user/logout").then((res) => {
								if(res.data.code == 0) {
									Toast('退出成功')
									localStorage.removeItem("phone")
									this.$router.push({name:'Home'})
								}else{
									Toast(res.data.msg);
								}
							})
						} else {
							Toast(res.data.msg);
						}
					})
				}
			}
		}
	}
</script>

<style>
	.askfdj {
		width: 90%;
		margin: 0 auto;
		padding: 0.2rem 0;
	}
	
	.askfdj>div {
		display: flex;
		flex-direction: row;
		align-items: center;
		border: 0.01rem solid #e5e5e5;
		border-radius: 0.3rem;
		background: #fff;
		height: 0.5rem;
		margin: 0.1rem 0;
	}
	
	.scy {
		width: 0.23rem;
		height: 0.3rem;
		margin-left: 0.3rem;
		margin-right: 0.2rem;
	}
	
	.inbf {
		width: 40%;
	}
	
	
	.tubioi {
		width: 0.2rem;
		height: 0.15rem;
	}
	
	.dfgd {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		text-align: center;
		color: #fff;
		background: #057be3;
		border-radius: 0.3rem;
		margin: 0.5rem auto;
	}
</style>