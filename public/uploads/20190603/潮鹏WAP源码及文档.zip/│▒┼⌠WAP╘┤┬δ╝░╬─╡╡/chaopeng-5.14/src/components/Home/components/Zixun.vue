<template>
	<div class="can" style="padding:0.05rem 0;">
		<div class="wcmh">
			<div>行业资讯</div>
			<div class="gengduo">
				<div>
					<router-link :to="{name:'listzx'}">
						查看更多》
					</router-link>
				</div>
				<div></div>
			</div>
		</div>

		<router-link class="zixun" v-for="( item , index ) in zixun" :key="index" :to="{name:'listxq'}">
			<div class="ggy"><img src="static/image/consult.png" style="width:100%;height:100%;" /></div>
			<div class="vmbn">
				<div class="wsx">{{item.name}}</div>
				<div class="rong">{{item.leirong}}</div>
				<div class="duo">
					<router-link :to="{name:'listzx'}">
						更多》
					</router-link>
				</div>
			</div>
		</router-link>
	</div>
</template>

<script>
	export default {
		name: "Zixun",
		data() {
			return {
				zixun: [{
						name: '欢迎潮鹏网站上线',
						leirong: '欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线'
					},
					{
						name: '欢迎潮鹏网站上线',
						leirong: '欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线'
					},
					{
						name: '欢迎潮鹏网站上线',
						leirong: '欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线'
					},
					{
						name: '欢迎潮鹏网站上线',
						leirong: '欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线欢迎潮鹏网站上线'
					}
				]
			}
		}
	}
</script>

<style>
	.wcmh {
		position: relative;
		width: 90%;
		left: 5%;
		padding: 0.05rem 0 0.05rem;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.gengduo {
		font-size: 12px;
		color: #999999;
		line-height: 0.2rem;
	}
	
	.zixun {
		width: 90%;
		margin: 0.05rem auto;
		border-bottom: 0.01rem solid #e5e5e5;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.05rem 0;
	}
	
	.ggy {
		width: 40%;
		height: 0.95rem;
	}
	
	.vmbn {
		width: 58%;
	}
	
	.wsx {
		font-size: 0.14rem;
		font-weight: bold;
		width: 100%;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}
	
	.rong {
		width: 100%;
		display: -webkit-box;
		/*作为弹性伸缩盒子模型显示*/
		-webkit-line-clamp:3;
		/*显示的行数；如果要设置2行加...则设置为2*/
		overflow: hidden;
		text-overflow: ellipsis;
		/* 溢出用省略号*/
		/*! autoprefixer: off */
		-webkit-box-orient: vertical;
		/*伸缩盒子的子元素排列：从上到下*/
		/* autoprefixer: on */
		font-size: 0.12rem;
	}
	
	.duo {
		width: 100%;
		text-align: end;
		font-size: 0.12rem;
		color: #999999;
		margin: 0.05rem 0;
	}
</style>