<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="订单详情" left-arrow @click-left="onClickLeft" fixed />
		<div class="wwr">
			<div class="wvfd" v-for="(item,index) in wsgh" :key="index" v-if="item.type==0">
				<div style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;">
					<div style="font-size:0.18rem;">{{item.name	}}</div>
					<div style="color:#4d83ff;">体检套餐：{{item.checkupPlanName}}</div>
				</div>
				<div>性别：{{item.sexStr}}</div>
				<div style="display: flex;flex-direction: row;">
					<div>年龄：{{item.age}}</div>
					<div style="margin-left:1rem;">职业：{{item.job}}</div>
				</div>
				<div>单位名称：{{item.orgName}}</div>
				<div>身份证号：{{item.cardId}}</div>
				<div>电话：{{item.mobile}}</div>
				<div>通信地址：{{item.contactAddress}}</div>
				<div v-if="item.salesManId!= null ">业务员ID：{{item.salesManId}}</div>
				<div style="color:red;width:100%;font-size:0.18rem;display: flex;justify-content: flex-end;">￥{{item.price}}元</div>
			</div>
			<div class="wvfd" v-for="(item,index) in wsgh" :key="index" v-if="item.type==1">
				<div style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;">
					<div style="color:#4d83ff;">体检套餐：{{item.checkupPlanName}}</div>
				</div>
				<div>体检人数：{{item.checkNum}}</div>
				<div>电话：{{item.mobile}}</div>
				<div>E-mail：{{item.email}}</div>
				<div>单位名称：{{item.orgName}}</div>
				<div>单位地址：{{item.contactAddress}}</div>
				<div v-if="item.salesManId!=null">业务员ID：{{item.salesManId}}</div>
				<div style="color:red;width:100%;font-size:0.18rem;display: flex;justify-content: flex-end;">￥{{item.price}}元</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'ddjl',
		data () {
			return {
				wsgh:''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			}
		},
		mounted() {
			this.$axios.post("/user/order/getOrderDetail", {
				"orderId": this.$route.query.id
			}).then((res) => {
				var lists = res.data.data.orderDetail;
				this.wsgh=lists;
				console.log(lists)
			})
		}
	}
</script>

<style>
	.wwr {
		width: 100%;
		background: #fff;
	}
	
	.wvfd {
		width: 90%;
		margin: 0 auto;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.wvfd>div {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.04rem 0;
	}
	.footer {
		width: 100%;
		height: 0.5rem;
		line-height: 0.5rem;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		position: fixed;
		bottom: 0;
		background: #fff;
		text-align: center;
	}
	
	.wvt {
		width: 35%;
		height: 0.35rem;
		line-height: 0.35rem;
		background: #cb5b17;
		border-radius: 0.3rem;
		color: #fff;
		margin-right: 0.15rem;
	}
</style>