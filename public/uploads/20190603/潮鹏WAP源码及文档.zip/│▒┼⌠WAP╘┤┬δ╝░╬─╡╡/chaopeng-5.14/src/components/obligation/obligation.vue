<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="待付款" left-arrow @click-left="onClickLeft" fixed />
		<div class="wesf" v-for="(item,index) in idlist" :key="index">
			<div class="pkh">
				<div>
					<div>{{item.payTitle}}</div>
					<div v-if="item.checkupUserType==0">个人购买</div>
					<div v-if="item.checkupUserType==1">团队购买</div>
				</div>
				<div style="color:#a0a0a0;">日期：{{timeFil(item.createTime)}}</div>
				<div style="color:#ff0000;font-size:0.18rem;">￥{{item.price}}</div>
				<div style="width:55%;margin-left:45%;">
					<div class="shanchue" @click="deledf(item.id)">删除订单</div>
					<div @click="skjhg(item.price,item.id)" class="fikuang">去付款</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "obligation",
		data() {
			return {
				idlist: ''
			};
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			dfkdd() { //获取待付款订单
				this.$axios.post("/user/order/readList", {
					"orderStatus": 0,
					"start": 1,
					"pageSize": 100000,
				}).then((res) => {
					var lists = res.data.data;
					console.log(lists)
					this.idlist = lists;
				})
			},
			skjhg(price,id) { //去付款
				this.$router.push({
					name: 'ddxiang',
					query: {
						price:price,
						id: id
					}
				})
			},
			deledf(id) {
				var _this=this;
				_this.$axios.post("/user/order/delOrder", {
					"orderId": id
				}).then((res) => {
					if(res.data.code == 0) {
						Toast('删除成功')
						setTimeout(() => {
							_this.dfkdd()
						},1000)
					}else{
						Toast(res.msg)
					}
				})
			},
			addZero(num) {
				if(parseInt(num) < 10) {
					num = '0' + num;
				}
				return num;
			},
			// 修改日期格式
			timeFil(timestamp) {
				var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000       
				var Y = date.getFullYear() + '-';
				var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
				var D = (date.getDate() < 10 ? ('0' + date.getDate()) : date.getDate()) + ' ';
				var h = date.getHours() < 10 ? ('0' + (date.getHours() + ':')) : (date.getHours() + ':');
				var m = date.getMinutes() < 10 ? ('0' + (date.getMinutes())) : (date.getMinutes());
				return Y + M + D + h + m;
			}
		},
		mounted() {
			this.dfkdd()
		}
	}
</script>

<style>
	.wesf {
		width: 100%;
		background: #fff;
	}
	
	.pkh {
		width: 90%;
		margin: 0 auto 0.1rem;
		padding: 0.1rem 0;
	}
	
	.pkh>div {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.04rem 0;
	}
	
	.shanchue {
		width: 0.8rem;
		height: 0.35rem;
		line-height: 0.35rem;
		text-align: center;
		color: #757575;
		border-radius: 0.05rem;
		border: 0.01rem solid #e5e5e5;
	}
	
	.fikuang {
		width: 0.8rem;
		height: 0.35rem;
		line-height: 0.35rem;
		text-align: center;
		color: #fff;
		background: #3778ff;
		border-radius: 0.05rem;
	}
</style>