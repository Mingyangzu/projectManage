<template>
	<div>
		<van-nav-bar title="咨询列表" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;background: #fff;margin-bottom:0.6rem;">
			<router-link :to="{name:'listxq'}" v-for="(can,index) in items" :key="index" class="wsu">
				<div class="tut">
					<img :src="can.img" style="width:100%;height:100%;" />
				</div>
				<div class="qing">
					<div style="color:#494949;font-size:0.16rem;">{{can.name}}</div>
					<div class="ziz">{{can.jianjie}}</div>
					<div class="money">
						<div style="color:#999999;font-size:0.16rem;">{{can.money}}</div>
					</div>
				</div>
			</router-link>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'listzx',
		data() {
			return {
				items: [{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25"
					},
					{
						name: "欢迎潮鹏网站上线",
						img: "static/image/xiang.png",
						jianjie: "健康体检的程序一般是在空腹的前提下完成抽血化验完成抽血化验",
						money: "2019-3-25",
					},
				]
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			}
		}
	}
</script>

<style>
</style>
