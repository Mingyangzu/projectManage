<template>
	<div>
		<van-nav-bar title="团队信息" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;">
			<div style="background: #fff;">
				<div class="lei">
					<div class="xvb">单位名称</div>
					<div><input placeholder="输入单位名称" v-model="dwmc" class="wxts"/></div>
				</div>
				<div class="lei" @click="taocan">
					<div class="xvb">体检套餐</div>
					<div>{{lei}}</div>
				</div>
				<div class="lei">
					<div class="xvb">手机号码</div>
					<div><input placeholder="输入电话号码" type="number" v-model="sjhm" class="wxts" /></div>
				</div>
				<div class="lei">
					<div class="xvb">体检人数</div>
					<div><input placeholder="输入体检人数" v-model="renshu" class="wxts" type="number" /></div>
				</div>
				<div class="lei">
					<div class="xvb">E-mail</div>
					<div><input placeholder="输入邮箱" v-model="email" class="wxts"/></div>
				</div>
				<div class="lei">
					<div class="xvb">HR联系方式</div>
					<div><input placeholder="非必填" type="number" v-model="phoneHr" class="wxts" /></div>
				</div>
				<div class="lei">
					<div class="xvb">业务员ID</div>
					<div><input placeholder="非必填" type="text" v-model="wywy" class="wxts" /></div>
				</div>
				<div class="address">
					<div>单位地址</div>
					<div><input placeholder="例：北京市朝阳区立水桥北8号" class="inpt" v-model="dwdz" /></div>
				</div>
			</div>
		</div>
		<van-popup v-model="can" position="bottom" :overlay="true" :close-on-click-overlay="true">
			<van-picker show-toolbar title="套餐选择" :default-index="xuanzhong" :columns="columns" @cancel="onCancel" @confirm="onConfirm" @change="onchange" />
		</van-popup>
		<div class="queren" @click="ssxy" v-if="tid==''">保存</div>
		<div class="queren" @click="tdxg" v-if="tid!=''">修改</div>
	</div>
</template>

<script>
	var myreg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
	var email = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/;
	import { Toast } from 'vant';
	export default {
		name: "AddTeamxinxi",
		data() {
			return {
				can: false,
				lei: '请选择',
				columns: [],
				id: 0,
				dwmc: '',
				sjhm: '',
				renshu: '',
				email: '',
				dwdz: '',
				wywy: '',
				phoneHr:'',
				tid: '',
				xuanzhong:0
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			taocan() {
				this.can = true;
			},
			onCancel() {
				this.can = false;
			},
			onchange (picker, values) {
				var getIndexes=picker.getIndexes(1);
				this.$axios.post("/checkupPlan/readList", {
					"start": 1,
					"pageSize": 100000,
					"orderType": 1,
				}).then((res) => {
					if(res.data.code == 0) {
						var taocan = res.data.data;
						var first={};
						first.id=null;
						first.name='请选择';
						taocan.unshift(first);
						this.id=taocan[getIndexes[0]].id;
					}
				})
			},
			onConfirm(value, index) {
				this.can = false;
				this.lei = value;
			},
			ssxy() { //添加
				if(this.dwmc == '') {
					Toast('请输入单位名称')
				} else if(myreg.test(this.sjhm)) {
					if(this.renshu == '') {
						Toast('请输入体检人数')
					} else if(email.test(this.email)) {
						if(this.dwdz == '') {
							Toast('请输入单位地址')
						} else if(this.lei == '请选择') {
							Toast('请选择体检套餐')
						} else {
							this.$axios.post("/user/checkupUser/addMultiple", {
								"checkupPlanId": this.id,
								"mobile": this.sjhm,
								"orgName": this.dwmc,
								"checkNum": this.renshu,
								"email": this.email,
								"contactAddress": this.dwdz,
								"hrMobile":this.phoneHr,
								"salesManId": this.wywy
							}).then((res) => {
								if(res.data.code == 0) {
									Toast('添加成功')
									this.$router.push({
										name: 'Team'
									})
								}
							})
						}
					} else {
						Toast('请输入正确的邮箱地址')
					}
				} else {
					Toast('请输入正确手机号码')
				}
			},
			tdxg() { //修改
				if(this.dwmc == '') {
					Toast('请输入单位名称')
				} else if(myreg.test(this.sjhm)) {
					if(this.renshu == '') {
						Toast('请输入体检人数')
					} else if(email.test(this.email)) {
						if(this.dwdz == '') {
							Toast('请输入单位地址')
						} else if(this.lei == '请选择') {
							Toast('请选择体检套餐')
						} else {
							this.$axios.post("/user/checkupUser/modifyMultipleInfo", {
								"id": this.tid,
								"checkupPlanId": this.id,
								"mobile": this.sjhm,
								"orgName": this.dwmc,
								"checkNum": this.renshu,
								"email": this.email,
								"contactAddress": this.dwdz,
								"hrMobile":this.phoneHr,
								"salesManId": this.wywy
							}).then((res) => {
								if(res.data.code == 0) {
									Toast('修改成功')
									this.$router.push({
										name: 'Team'
									})
								}
							})
						}
					} else {
						Toast('请输入正确的邮箱地址')
					}
				} else {
					Toast('请输入正确手机号码')
				}
			}
		},
		mounted() {
			this.$axios.post("/checkupPlan/readList", {
				"start": 1,
				"pageSize": 100000,
				"orderType": 1,
			}).then((res) => {
				if(res.data.code == 0) {
					var taocan = res.data.data;
					var first={};
						first.id=null;
						first.name='请选择';
						taocan.unshift(first);
					for(var i = 0; i < taocan.length; i++) {
						this.columns.push(taocan[i].name)
						if(this.$route.query.tid) {
							this.id=this.$route.query.tid;
							if(taocan[i].id==this.$route.query.tid){
								this.xuanzhong=i
								this.lei=taocan[i].name
							}
						}
					}
				}
			})
			if(this.$route.query.id) { //获取指定团队信息
				this.tid = this.$route.query.id
				this.$axios.get("/user/checkupUser/queryMultipleInfo?checkupUserId=" + this.$route.query.id).then((res) => {
					if(res.data.code == 0) {
						var grxx = res.data.data;
						this.dwmc = grxx.orgName;
						this.sjhm = grxx.mobile;
						this.renshu = grxx.checkNum;
						this.email = grxx.email;
						this.dwdz = grxx.contactAddress;
						this.wywy = grxx.salesManId;
						this.phoneHr=grxx.hrMobile;
					}
				})
			}
		}
	}
</script>

<style>
	.lei {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		align-items: center;
		padding: 0.15rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.wxts {
		border: none;
	}
	
	.xvb {
		width: 0.6rem;
		margin-right:10%;
	}
	
	.radio {
		display: flex;
		flex-direction: row;
	}
	
	.van-radio {
		margin-right: 0.2rem;
	}
	
	.address {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		padding: 0.15rem 0;
	}
	
	.inpt {
		margin-left: 0;
		padding: 0.2rem 0;
		width: 80%;
		border:none;
	}
	
	.queren {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		border-radius: 0.3rem;
		text-align: center;
		background: #3778ff;
		margin: 0.3rem auto;
	}
</style>