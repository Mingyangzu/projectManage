<template>
	<nav>
		<ul>
			<li>
				<router-link to="/">
					<div class="xxm">
						<img src="static/image/tabbar_01.png" />
					</div>
					首页
				</router-link>
			</li>
			<li>
				<router-link to="/Consult">
					<div class="xxm">
						<img src="static/image/tabbar_03.png" />
					</div>资讯
				</router-link>
			</li>
			<li>
				<div class="xxm">
					<img src="static/image/tabbar_09.png" />
				</div>潮鹏
			</li>
			<li>
				<router-link to="/chaopeng">
					<div class="xxm">
						<img src="static/image/tabbar_05.png" />
					</div>报告
				</router-link>
			</li>
			<li>
				<router-link to="/my">
					<div class="xxm">
						<img src="static/image/tabbar_07.png" />
					</div>我的
				</router-link>
			</li>
		</ul>
	</nav>
</template>

<script>
	export default {
		name: 'Footer'
	}
</script>

<style>
	nav {
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 0.55rem;
		background: #fff;
	}
	
	nav ul {
		display: flex;
	}
	
	nav ul li {
		padding: 0.06rem 0;
		flex: 1;
		text-align: center;
	}
	
	.xxm {
		width: 0.26rem;
		height: 0.26rem;
		margin: 0 auto;
	}
	
	a {
		color: #000;
	}
	
	.router-link-exact-active {
		color: #3778ff;
	}
</style>