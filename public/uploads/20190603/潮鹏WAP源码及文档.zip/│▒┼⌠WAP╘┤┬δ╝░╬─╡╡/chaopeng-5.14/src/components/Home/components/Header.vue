<template>
	<div class="header1">
		<div class="deng1">
			<router-link :to="{name:'login'}" style="color:#fff;" v-if="show1==501">
				登录
			</router-link>
		</div>
		<div class="logo1">
			<img src="static/image/logo.png" style="width:100%;height:100%;" />
		</div>
		<div class="san1">
			
		</div>
	</div>
</template>

<script>
	export default {
		name:"Header",
		data () {
			return {
				show1:''
			}
		},
		mounted() {
			
		}
	}
</script>

<style>
	
</style>
