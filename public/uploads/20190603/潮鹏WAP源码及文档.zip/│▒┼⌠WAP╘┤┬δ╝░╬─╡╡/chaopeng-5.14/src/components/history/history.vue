<template>
	<div>
		<van-nav-bar title="预约历史" left-arrow @click-left="onClickLeft" fixed />
		<div style="background: #fff;margin-top:0.46rem;">
			<div class="wsou">
				<div><input placeholder="输入预约码" v-model="yfgh" /></div>
				<div><input placeholder="输入手机号" v-model="shoujyg" /></div>
				<div @click="yyss" style="width:10%;">搜索</div>
			</div>
			<div v-for="(item,index) in lishi" :key="index" v-if="yyxx==''">
				<div style="background:#f6f6f6;color:#a5a5a5;padding:0.06rem 0 0.06rem 0.22rem;">{{item.dateStr}}</div>
				<div class="lishi" v-for="(items,index) in item.list" :key="index">
					<div>
						<div style="font-size:0.18rem;">{{items.checkupPlanName}}</div>
						<div style="color:#5f8eff" v-if="items.type==0">个人购买</div>
						<div style="color:#5f8eff" v-if="items.type==1">团体购买</div>
					</div>
					<div>
						<div>姓名：{{items.name}}</div>
					</div>
					<div>
						<div>手机号码：{{items.mobile}}</div>
					</div>
					<div>医院：{{items.hospitalName}}</div>
					<div>体检日期：{{items.checkTime}}</div>
				</div>
			</div>
			<div v-if="yyxx!=''" style="position: fixed;top:1.15rem;background: #fff;width:100%;">
				<div class="lishi">
					<div v-if="yyxx.name!=null">
						<div>姓名：{{yyxx.name}}</div>
					</div>
					<div>
						<div>手机号码：{{yyxx.mobile}}</div>
					</div>
					<div>预约码：{{yyxx.checkCode}}</div>
					<div>体检医院：{{yyxx.hospitalName}}</div>
					<div>体检日期：{{yyxx.checkTime}}</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "history",
		data() {
			return {
				lishi: '',
				yfgh:'',
				shoujyg:'',
				yyxx:''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			yyss () {
				if(this.yfgh==''){
					Toast('请输入预约码')
				}else if(this.shoujyg==''){
					Toast('请输入手机号')
				}else{
					this.$axios.post("/user/appointment/query", {
						"checkCode": this.yfgh,
						"mobile": this.shoujyg
					}).then((res) => {
						if(res.data.code == 0) {
							this.yyxx=res.data.data;
							console.log(res.data.data)
						}
					})
				}
			}
		},
		mounted() {
			this.$axios.post("/user/appointment/history", {
				"start": 1,
				"pageSize": 100000
			}).then((res) => {
				if(res.data.code == 0) {
					console.log(res.data.data)
					this.lishi = res.data.data;
				}
			})
		}
	}
</script>

<style>
	.wsou{
		display: flex;
		flex-direction: row;
		justify-content:space-between;
		align-items: center;
		padding:0.1rem 0;
		width:95%;
		margin:0 auto;
	}
	.wsou>div{
		width:35%;
		overflow: hidden;
		text-align: center;
	}
	.wsou input{
		width:95%;
		height:0.4rem;
		line-height: 0.4rem;
		border:0.01rem solid #e5e5e5;
		text-align: center;
	}
	.lishi {
		width: 90%;
		margin: 0 auto;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.lishi>div {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		line-height: 0.3rem;
		color: #323232;
	}
</style>