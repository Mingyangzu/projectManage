<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="支付成功" fixed />
		<div class="khfik">
			<div class="tishi">
				<img src="static/image/success.png" style="width:100%;height:100%;" />
			</div>
			<div style="margin:0.1rem 0;color:#999999">支付成功</div>
			<div><span class="miao">{{time}}</span>秒后进入个人中心页面</div>
		</div>
	</div>
</template>

<script>
	var timer=null;
	export default {
		data () {
			return {
				time:'3'
			}
		},
		methods:{
			settime() {
				var that = this; //习惯
				timer = setInterval(function() {
					if (that.time <= 0) {
						clearInterval(timer); //这句话至关重要
						that.$router.push({name:'My'})
					} else {
						that.time--;
					}
				}, 1000);
			}
		},
		mounted () {
			this.settime()
		}
	}
</script>

<style>
	.khfik{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.tishi {
		width: 0.8rem;
		height: 0.8rem;
		margin:0.3rem 0 0.1rem;
	}
	.miao{
		font-size:0.24rem;
		color:#057BE3;
		font-weight: bold;
	}
</style>