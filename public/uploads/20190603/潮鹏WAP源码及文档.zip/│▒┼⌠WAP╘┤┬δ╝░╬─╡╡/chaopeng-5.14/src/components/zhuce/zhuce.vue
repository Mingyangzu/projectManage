<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="注册会员" left-arrow @click-left="onClickLeft" fixed />
		<div style="background: #fff;">
			<div class="ce">
				<span>我已注册，马上</span>
				<span style="color:#358ee7;" @click="dengty">登录</span>
			</div>
		</div>
		<div>
			<van-steps :active="active" active-color="#057be3">
				<van-step>设置登录名</van-step>
				<van-step>设置用户信息</van-step>
				<van-step>注册成功</van-step>
			</van-steps>
		</div>
		<div style="background: #fff;padding-bottom:0.6rem;" v-if="show1">
			<div class="dft">
				<div style="width:93%;border:0.01rem solid #e5e5e5;padding:0.08rem 0.1rem;">
					<div style="width:7%;height:0.3rem;">
						<img src="static/image/zhuce.png" />
					</div>
					<div>
						<input placeholder="请输入您的手机号" type="number" style="width:92%;height:0.3rem;padding-left:0.2rem;" v-model="phone1" />
					</div>
				</div>
				<div style="display: flex;justify-content: space-between;">
					<div style="width:55%;border:0.01rem solid #e5e5e5;padding:0.08rem 0.1rem;display: flex;flex-direction: row;align-items: center;">
						<div style="width:13%;height:0.3rem;">
							<img src="static/image/ccv.png" />
						</div>
						<div><input placeholder="请输入验证码" style="width:58%;height:0.3rem;padding-left:0.2rem;" v-model="yzm1" /></div>
					</div>
					<div class="yzmws" @click="getzhuce">{{hqyzm}}</div>
				</div>
				<div style="display: flex;justify-content: space-between;">
					<div style="width:64%;border:0.01rem solid #e5e5e5;padding:0.08rem 0.1rem;display: flex;flex-direction: row;align-items: center;">
						<div style="width:11%;height:0.3rem;">
							<img src="static/image/ccv.png" />
						</div>
						<div><input placeholder="请输入验证码" style="width:58%;height:0.3rem;padding-left:0.2rem;" v-model="tyz1" /></div>
					</div>
					<div class="yzmws" @click="changeCodeImg()">
						<img :src="codeImg" alt="图片加载失败" />
					</div>
				</div>
				<div>
					<div style="margin-right:0.1rem;">
						<van-checkbox v-model="checked" @change="chexk"></van-checkbox>
					</div>
					<div style="color:#555555;">同意《潮鹏体验网用户协议》</div>
				</div>
			</div>
			<div class="wws" @click="ssh">下一步</div>
		</div>
		<div style="background: #fff;padding-bottom:0.6rem;" v-if="show2">
			<div class="pass">
				<div>
					<div class="yaoshi">
						<img src="static/image/yaoshi.png" />
					</div>
					<div><input placeholder="请设置6-12位密码" type="password" style="padding-left:0.2rem;" v-model="mima1" /></div>
				</div>
				<div>
					<div class="yaoshi">
						<img src="static/image/yaoshi.png" />
					</div>
					<div><input placeholder="请重新输入密码" type="password" style="padding-left:0.2rem;" v-model="mima2" /></div>
				</div>
			</div>
			<div class="wws" @click="qqd">下一步</div>
		</div>
		<div style="background: #fff;padding-bottom:0.6rem;" v-if="show3">
			<div style="width:95%;margin:0 auto;text-align: center;padding:0.2rem;color:#535353;font-size:0.18rem;">
				恭喜{{phone1}}注册成功
			</div>
			<div class="wws" @click="denglu">登录</router-link>
			</div>
		</div>
	</div>
</template>

<script>
	var timer=null;
	import { Toast } from 'vant';
	export default {
		name: "zhuce",
		data() {
			return {
				phone1: '',
				yzm1: '',
				tyz1: '',
				show1: true,
				show2: false,
				show3: false,
				active: 0,
				checked: true,
				mima1: '',
				mima2: '',
				codeImg: '',
				hqyzm:'获取验证码'
			};
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			denglu () {
				this.$router.push({name: 'login'});
			},
			dengty () {
				this.$router.push({name: 'login'});
			},
			chexk () {
				console.log(this.checked)
			},
			changeCodeImg: function() {　　　//刷新图片码
				var num = Math.ceil(Math.random() * 10); //生成一个随机数（防止缓存）
				this.codeImg = 'https://www.chaopengjiankang.com/api/user/captcha.jpg?' + num;　　
			},
			settime() {
				var time = 60;
				var that = this; //习惯
				timer = setInterval(function() {
					if (time <= 0) {
						that.hqyzm = "点击重新发送";
						clearInterval(timer); //这句话至关重要
					} else {
						that.hqyzm = (time) + "秒";
						time--;
					}
				}, 1000);
			},
			ssh() { //第一步
				var that=this;
				if (that.phone1 == '') {
					Toast('请输入手机号');
				} else if (that.yzm1 == '') {
					Toast('请输入手机验证码');
				} else if (that.tyz1 == '') {
					Toast('请输入图片验证码');
				} else if(that.checked == false){
					Toast('请同意潮鹏用户协议');
				}else {
					that.$axios.post("/user/register/checkCode", {
						"mobile": that.phone1,
						"smsCode": this.yzm1,
						"captchaCode":that.tyz1
					}).then((res) => {
						if (res.data.code == 0) {
							that.active = 1;
							that.show1 = false;
							that.show2 = true;
						}
					})
				}
			},
			qqd() {  //第二步
				if (this.mima1 == '') {
					Toast('请输入6-12密码');
				} else {
					var pattern = /^[\w_-]{6,12}$/;
					if (pattern.test(this.mima1)) {
						if (this.mima1 == this.mima2) {
							this.active = 2;
							this.show2 = false;
							this.show3 = true;
							this.$axios.post("/user/register/create", {
								"mobile": this.phone1,
								"password":this.mima1
							}).then((res) => {
								if (res.data.code == 0) {
									Toast('注册成功');
								}
							})
						}else{
							Toast('两次密码不一致');
						}
					} else {
						Toast('密码格式错误,请输入6-12密码');
					}
				}
			},
			getzhuce() {
				var phone = this.phone1;
				if (phone == '') {
					Toast('请输入手机号');
				}else{
					var myreg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
					if (myreg.test(phone)) {
						this.$axios.post("/user/register/makeSmsCode", {
							"mobile": phone,
							"smsType": "1"
						}).then((res) => {
							console.log(res)
							if (res.data.code == 0) {
								Toast('验证码发送成功');
								setTimeout(res => {
									this.settime();
								}, 1000);
							}else{
								Toast(res.data.msg);
							}
						})
					} else {
						this.phone1 = '';
						Toast('手机号格式错误');
					}
				}
			}
		},
		created() {
			this.changeCodeImg()
		}
	}
</script>

<style>
	.ce {
		width: 90%;
		margin: 0 auto;
		display: flex;
		justify-content: flex-end;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}

	.dft {
		width: 90%;
		margin: 0 auto;
		padding: 0.1rem 0 0;
	}

	.dft>div {
		display: flex;
		flex-direction: row;
		align-items: center;
		margin-bottom: 0.15rem;
	}

	input {
		border: none;
	}

	.yzmws {
		width: 30%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		text-align: center;
		background: #057be3;
	}

	.wws {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		text-align: center;
		color: #fff;
		background: #057be3;
		border-radius: 0.06rem;
		margin: 0 auto;
	}

	.van-checkbox__icon--round .van-icon {
		border-radius: 0;
	}

	.van-step--finish .van-step__circle,
	.van-step--finish .van-step__line {
		background: #057BE3;
	}

	.pass {
		width: 90%;
		margin: 0 auto;
	}

	.pass>div {
		border: 0.01rem solid #e5e5e5;
		display: flex;
		flex-direction: row;
		align-items: center;
		padding: 0.1rem;
		margin-bottom: 0.2rem;
	}

	.yaoshi {
		width: 5%;
		height: 0.3rem;
		border-right: 0.01rem solid #e5e5e5;
		padding-right: 0.2rem;
	}
</style>
