<template>
	<div>
		<div class="header1">
			<div class="deng1"></div>
			<div class="logo1">
				<img src="static/image/logo.png" style="width:100%;height:100%;" />
			</div>
			<div class="san1"></div>
		</div>
		<div class="geren">
			<div style="width:90%;margin:0 auto;display: flex;flex-direction: row;justify-content:space-between;align-items: center;padding:0.15rem 0;border-bottom:0.01rem solid #e5e5e5;">
				<div class="wun">
					<div style="font-size:0.18rem;">
						<router-link :to="{name:'login'}" v-if="name==null">
							点击登录
						</router-link>
					</div>
					<div style="color:#323232;font-size:0.16rem;" v-if="name!=''">{{name}}</div>
				</div>
				<div>
					<a @click="grxx">
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</a>
				</div>
			</div>
			<div class="yue">
				<div @click="dfkk">
						<div class="icons"><img src="static/image/ka.png" /></div>
						<div style="margin-top:0.1rem;">待付款</div>
				</div>
				<div @click="tjyy">
						<div class="icons"><img src="static/image/zhong.png" /></div>
						<div style="margin-top:0.1rem;">体检预约</div>
				</div>
			</div>
		</div>
		<div style="background: #fff;margin-top:0.05rem;">
			<div class="liebiao">
				<a @click="ddjl">
					<div>订单记录</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
				<a @click="grtj">
					<div>个人体检信息</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
				<a @click="tdtj">
					<div>团队体检信息</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
				<a @click="yyls">
					<div>预约历史</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
				<a @click="women">
					<div>关于我们</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
				<a style="border:none;" @click="shezhi">
					<div>设置</div>
					<div>
						<van-icon name="arrow" size="0.2rem" color="#9f9f9f" />
					</div>
				</a>
			</div>
		</div>
		<div class="snb">Copyrigt @ 2019-2020 潮鹏管理 版权所有京ICP备16051221号</div>
		<Footer></Footer>
	</div>
</template>

<script>
	var citys = {};
	import { Toast } from 'vant';
	import Footer from '@/components/Footer/Footer'
	export default {
		name: "My",
		data () {
			return {
				list:'',
				name:''
			}
		},
		components: {
			Footer
		},
		methods:{
			grxx () {  //个人信息
				this.$router.push({name:'Grzs'})
			},
			dfkk () {  //待付款 ok
				this.$router.push({name:'obligation'})
			},
			tjyy () {  //体检预约  ok
				this.$router.push({name:'subscribe',query:{citys:citys}})
			},
			ddjl () {   //订单记录
				this.$router.push({name:'orderjilu'})   
			},
			grtj () {   //个人体检信息
				this.$router.push({name:'Personage'})
			},
			tdtj () {   //团队体检信息
				this.$router.push({name:'Team'})
			},
			yyls () { //预约历史
				this.$router.push({name:'history'})
			}, 
			women () {
				this.$router.push({name:'women'})
			},
			shezhi () {   //设置
				this.$router.push({name:'shezhi'})
			}
		},
		mounted() {
			this.$axios.get("/hospital/queryAll").then((res) => {
				if(res.data.code == 0) {
					var data = res.data.data;
					console.log(data)
					var yiyuan={};
					yiyuan.areaName='请选择';
					var hospitalList=[];
					var zilei={};
					zilei.name='请选择';
					zilei.id='df5';
					hospitalList.push(zilei);
					yiyuan.hospitalList=hospitalList;
					data.unshift(yiyuan);
					console.log(data)
					this.yyid=data[0].hospitalList[0].id;
					for(var i = 0; i < data.length; i++) {
						var keys = data[i].areaName;
						var hospitalList = [];
						for(var j = 0; j < data[i].hospitalList.length; j++) {
							var values = data[i].hospitalList[j].name;
							hospitalList.push(values)
						}
						citys[keys] = hospitalList;
					}
				}else if(res.data.code==501){
					this.$router.push({name:'login'})
				}
			})
			this.name=localStorage.getItem("phone");
		}
	}
</script>

<style>
	.geren {
		width: 85%;
		background: #fff;
		margin:0.5rem auto 0.06rem;
		border-radius: 0.1rem;
		padding:0 0.15rem;
	}

	.touxiang {
		width: 0.6rem;
		height: 0.6rem;
		border-radius: 50%;
		margin-right: 0.2rem;
	}

	.wun {
		display: flex;
		flex-direction: column;
		align-items: center;
		line-height: 0.25rem;
	}

	.liebiao {
		width: 90%;
		margin: 0 auto;
	}

	.liebiao a{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.1rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}

	.yue {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		padding: 0.1rem 0 0.15rem;
	}

	.yue>div {
		width: 50%;
		text-align: center;
	}

	.icons {
		width: 0.3rem;
		height: 0.3rem;
		margin: 0 auto;
	}
	.snb{
		position: fixed;
		bottom:0.55rem;
		font-size:0.10rem;
		width:85%;
		left:7.5%;
		text-align: center;
		color:#999999;
		padding:0.05rem 0;
	}
</style>
