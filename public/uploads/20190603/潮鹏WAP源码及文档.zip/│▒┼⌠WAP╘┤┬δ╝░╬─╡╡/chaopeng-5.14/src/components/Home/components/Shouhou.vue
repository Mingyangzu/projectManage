<template>
	<div class="icon1">
		<div v-for="(item,index) in images" :key="index">
			<div class="tuu2">
				<img :src="item.img" class="img" />
			</div>
			<div>{{item.name}}</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Shouhou",
		data() {
			return {
				images: [{
						img: 'static/image/promise_01.png',
						name: '官方授权'
					},
					{
						img: 'static/image/promise_02.png',
						name: '诚信认真'
					},
					{
						img: 'static/image/promise_03.png',
						name: '低价承诺'
					},
					{
						img: 'static/image/promise_04.png',
						name: '检后服务'
					},
					{
						img: 'static/image/promise_05.png',
						name: '100%满意'
					}
				]
			}
		}
	}
</script>

<style>
	.icon1 {
		width: 100%;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
		font-size: 0.12rem;
	}
	
	.icon1>div {
		width: 20%;
		text-align: center;
		padding:0.05rem 0;
		background: #fff;
	}
	
	.tuu2 {
		width: 0.4rem;
		height: 0.4rem;
		margin: 0.04rem auto;
	}
	
	.img {
		width: 100%;
		height: 100%;
	}
</style>
