<template>
	<div>
		<van-nav-bar title="会员登录" left-arrow @click-left="onClickLeft" fixed />
		<div class="deng">
			<div class="yyt">欢迎登录潮鹏</div>
			<div class="ssv">
				<div style="width:17%;height:0.5rem;"><img src="static/image/yonghu.png" /></div>
				<div class="hhkj"><input placeholder="用户名/手机号" class="ppkj" v-model="phone2" /></div>
			</div>
			<div class="ssv">
				<div style="width:17%;height:0.5rem;"><img src="static/image/password.png" /></div>
				<div class="hhkj"><input placeholder="请输入密码" type="password" class="ppkj" v-model="pass2" /></div>
			</div>
			<div class="ssv">
				<div style="width:17%;height:0.5rem;">
					<img src="static/image/wwx.png" />
				</div>
				<div class="hhkj" style="width:53%;"><input placeholder="请输入验证码" class="ppkj" v-model="yzm2" /></div>
				<div class="yzmer" @click="changeCodeImg()">
					<img :src="codeImg" alt="图片加载失败" />
				</div>
			</div>
			<div class="login" @click="login">登录</div>
			<div class="wang">
				<div>
					<router-link :to="{name:'zhuce'}" style="color:#4d4d4d;">
						手机注册
					</router-link>
				</div>
				<div>
					<router-link :to="{name:'mima'}" style="color:#4d4d4d;">
						忘记密码?
					</router-link>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import {
		Toast
	} from 'vant';
	export default {
		name: "login",
		data() {
			return {
				codeImg: '',
				phone2: '',
				pass2: '',
				yzm2: ''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.push({
					name: 'Home'
				});
			},
			changeCodeImg: function() {　　　　
				var num = Math.ceil(Math.random() * 10); //生成一个随机数（防止缓存）
				this.codeImg = 'https://www.chaopengjiankang.com/api/user/captcha.jpg?' + num;　　
			},
			login() {
				if (this.phone2 == '') {
					Toast('请输入手机号');
				} else if (this.pass2 == '') {
					Toast('请输入密码');
				} else if (this.yzm2 == '') {
					Toast('请输入验证码');
				} else {
					this.$axios.post("/user/login", {
						"mobile": this.phone2,
						"password": this.pass2,
						"checkCode": this.yzm2
					}).then((res) => {
						if (res.data.code == 0) {
							Toast('登录成功');
							localStorage.setItem("phone", res.data.data);
							if(this.$route.query.redirect){
                                this.$router.push({path: decodeURIComponent(this.$route.query.redirect)}) //跳转到原页面
                            }else{
                                this.$router.push({name: 'Home'});//正常登录流程进入的页面
                            }
						}else{
							Toast(res.data.msg);
						}
					})
				}
			}
		},
		created() {
			this.changeCodeImg()
		}
	}
</script>

<style>
	.deng {
		width: 90%;
		margin: 0.46rem auto 0;
	}

	.yyt {
		width: 100%;
		text-align: center;
		padding: 0.2rem 0;
		font-size: 0.16rem;
		color: #757575;
	}

	.deng>div {
		margin: 0.2rem 0;
	}

	.ssv {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}

	.hhkj {
		width: 83%;
		height: 0.5rem;
	}

	.ppkj {
		width: 96%;
		height: 0.46rem;
		border: 0.01rem solid #e5e5e5;
		padding-left: 0.1rem;
	}

	.login {
		width: 100%;
		height: 0.5rem;
		line-height: 0.5rem;
		background: #057be3;
		color: #fff;
		text-align: center;
		border-radius: 0.06rem;
	}

	.wang {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}

	.yzmer {
		width: 30%;
		height: 0.46rem;
		color: #fff;
		border: 0.01rem solid #e5e5e5;
	}
</style>
