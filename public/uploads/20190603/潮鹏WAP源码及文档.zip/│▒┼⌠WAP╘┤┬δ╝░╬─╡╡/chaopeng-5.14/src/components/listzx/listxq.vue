<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="咨询详情" left-arrow @click-left="onClickLeft" fixed />
		<div style="background:#fff;padding-top:0.04rem">
			<div class="cyg">
				<div style="font-size:0.18rem;color:#323232;padding:0.05rem 0;">欢迎潮鹏网站上线</div>
				<div style="color:#999999;padding:0.05rem 0;">北京潮鹏健康管理有限公司</div>
				<div style="color:#999999;padding:0.05rem 0;">2018-03-27</div>
			</div>
			<div class="weny">
				等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是
				等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是
				等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是
				等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是等级考试付款方式开发离开是
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name:'listxq',
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			}
		}
	}
</script>

<style>
	.cyg{
		width:90%;
		margin:0 auto;
		border-bottom:0.01rem solid #e5e5e5;
	}
	.weny{
		width:90%;
		margin:0 auto;
		padding:0.1rem 0;
	}
</style>
