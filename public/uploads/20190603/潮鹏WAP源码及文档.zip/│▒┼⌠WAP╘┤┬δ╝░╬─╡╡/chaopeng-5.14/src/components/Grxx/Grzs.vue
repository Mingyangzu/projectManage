<template>
	<div>
		<van-nav-bar title="个人信息" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;">
			<div style="background: #fff;">
				<div class="lei">
					<div class="mnbg">昵称</div>
					<div>{{list.nickName}}</div>
				</div>
				<div class="lei">
					<div class="mnbg">真实姓名</div>
					<div>{{list.name}}</div>
				</div>
				<div class="lei">
					<div class="mnbg">出生年月</div>
					<div>{{list.dateOfBirth}}</div>
				</div>
				<div class="lei">
					<div class="mnbg">性别</div>
					<div v-if="list.sex==1">男</div>
					<div v-if="list.sex==0">女</div>
				</div>
				<div class="lei">
					<div class="mnbg">手机号码</div>
					<div>{{list.mobile}}</div>
				</div>
				<div class="lei">
					<div class="mnbg">身份证号</div>
					<div>{{list.cardId}}</div>
				</div>
				<div class="address">
					<div>联系地址</div>
					<div style="padding:0.15rem 0;">{{list.contactAddress}}</div>
				</div>
			</div>
		</div>
		<div class="queren" @click="xiugai">修改</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Grzs",
		data() {
			return {
				list:'',
			}
		},
		methods: {
			onClickLeft() {
				var ua = navigator.userAgent.toLowerCase();
			    if (ua.match(/MicroMessenger/i) == "micromessenger") {
			    	this.$router.push({
						name: 'Home'
					})
			    }else{
			    	this.$router.go(-1);
			    }
			},
			xiugai () {
				this.$router.push({name:'Grxx'})
			}
		},
		mounted() {
			this.$axios.get("/user/query").then((res) => {
				if (res.data.code == 0) {
					this.radio=JSON.stringify(res.data.data.sex);
					this.list = res.data.data;
					console.log(res.data.data)
				}
			})
		}
	}
</script>

<style>
	.lei {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		align-items: center;
		padding: 0.15rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}

	.tou {
		width: 0.5rem;
		height: 0.5rem;
		border-radius: 50%;
	}


	.mnbg {
		width: 0.6rem;
		margin-right:10%;
	}

	.radio {
		width:60%;
		display: flex;
		flex-direction: row;
	}

	.address {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		padding: 0.15rem 0;
	}

	.inpt {
		margin-left: 0;
		padding: 0.2rem 0;
		width: 80%;
	}

	.queren {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		border-radius: 0.3rem;
		text-align: center;
		background: #3778ff;
		margin: 0.3rem auto;
	}
</style>
