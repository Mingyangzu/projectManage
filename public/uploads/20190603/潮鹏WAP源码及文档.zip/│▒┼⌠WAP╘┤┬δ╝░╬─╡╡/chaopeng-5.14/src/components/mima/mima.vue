<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="忘记密码" left-arrow @click-left="onClickLeft" fixed />
		<div class="web">
			<div>
				<div class="scy">
					<img src="static/image/zhuce.png" />
				</div>
				<div class="inbf">
					<input placeholder="请输入手机号码" style="border:none;height:0.4rem;" v-model="phone3" />
				</div>
				<div class="yzm" style="background: #057be3;" @click="hqyzm">{{djs}}</div>
			</div>
			<div>
				<div class="scy" style="height:0.05rem;margin-top:-0.2rem;">
					<img src="static/image/sandian.png" />
				</div>
				<div class="inbf"><input placeholder="请输入短信验证码" style="border:none;height:0.4rem;" v-model="dxyzm" /></div>
				<div class="yzm"></div>
			</div>
			<div>
				<div class="scy">
					<img src="static/image/suo.png" />
				</div>
				<div class="inbf">
					<input placeholder="请输入6-12位密码" :type="type" style="border:none;height:0.4rem;" v-model="qsrmm" />
				</div>
				<div class="yzm" @click="yanjing" style="border-left: 0.01rem solid #e5e5e5;">
					<div class="tubioi">
						<img src="static/image/yanjing.png" />
					</div>
				</div>
			</div>
			<div>
				<div class="scy">
					<img src="static/image/suo.png" />
				</div>
				<div class="inbf">
					<input placeholder="请确认密码" :type="type" style="border:none;height:0.4rem;" v-model="passgh" />
				</div>
				<div class="yzm" @click="yanjing" style="border-left: 0.01rem solid #e5e5e5;">
					<div class="tubioi">
						<img src="static/image/yanjing.png" />
					</div>
				</div>
			</div>
		</div>
		<div class="ffvc" @click="queren">确认</div>
	</div>
</template>

<script>
	var timer=null;
	import {
		Toast
	} from 'vant'
	export default {
		name: 'mima',
		data() {
			return {
				type: "password",
				phone3: '',
				dxyzm: '',
				passgh: '',
				qsrmm: '',
				djs: '获取验证码'
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			yanjing() {
				if (this.type == "password") {
					this.type = "text"
				} else {
					this.type = "password"
				}
			},
			settime() {
				var time = 60;
				var that = this; //习惯
				timer = setInterval(function() {
					console.log(time)
					if (time <= 0) {
						that.djs = "点击重新发送";
						clearInterval(timer); //这句话至关重要
					} else {
						that.djs = (time) + "秒";
						time--;
					}
				}, 1000);
			},
			hqyzm() { //获取验证码
				if (this.phone3 == '') {
					Toast('请输入手机号');
				} else {
					var phone = this.phone3;
					var myreg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
					if (myreg.test(phone)) {
						this.$axios.post("/user/register/makeSmsCode", {
							"mobile": phone,
							"smsType": "2"
						}).then((res) => {
							console.log(res)
							if (res.data.code == 0) {
								Toast('验证码发送成功');
								setTimeout(res => {
									this.settime();
								}, 1000);
							} else {
								Toast(res.data.msg);
							}
						})
					} else {
						this.phone3 = '';
						Toast('手机号格式错误');
					}
				}
			},
			queren() { //确认
				if (this.phone3 == '') {
					Toast('请输入手机号');
				} else if (this.dxyzm == '') {
					Toast('请输入短信验证码');
				} else if (this.qsrmm == '') {
					Toast('请输入密码');
				} else {
					if (this.qsrmm == this.passgh) {
						var pattern = /^[\w_-]{6,12}$/;
						if (pattern.test(this.qsrmm)) {
							if (this.dxyzm == '') {
								Toast('请输入短信验证码');
							} else {
								this.$axios.post("/user/findPwd", {
									"mobile": this.phone3,
									"password": this.qsrmm,
									"confirmPassword": this.passgh,
									"smsCode": this.dxyzm
								}).then((res) => {
									console.log(res)
									if (res.data.code == 0) {
										Toast('成功,请登录');
										this.$router.push({
											name: 'login'
										})
									} else {
										Toast(res.data.msg);
									}
								})
							}
						} else {
							Toast('请输入6-12位的密码');
						}
					} else {
						Toast('两次密码不一致，请重新输入');
					}
				}
			}
		}
	}
</script>

<style>
	.web {
		width: 90%;
		margin: 0 auto;
		padding: 0.2rem 0;
	}

	.web>div {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		border: 0.01rem solid #e5e5e5;
		border-radius: 0.3rem;
		background: #fff;
		height: 0.5rem;
		margin: 0.1rem 0;
	}

	.scy {
		width: 0.23rem;
		height: 0.3rem;
		margin-left: 0.3rem;
		margin-right: 0.2rem;
	}
	.inbf{
		width:40%;
	}
	.yzm {
		width: 30%;
		height: 100%;
		line-height: 0.5rem;
		color: #fff;
		text-align: center;
		border-top-right-radius: 0.3rem;
		border-bottom-right-radius: 0.3rem;
		margin-left: 0.1rem;
		display: flex;
		justify-content: center;
	}
	.tubioi{
		width: 0.2rem;
		height: 0.15rem;
	}

	.ffvc {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		text-align: center;
		color: #fff;
		background: #057be3;
		border-radius: 0.3rem;
		margin: 0 auto;
	}
</style>
