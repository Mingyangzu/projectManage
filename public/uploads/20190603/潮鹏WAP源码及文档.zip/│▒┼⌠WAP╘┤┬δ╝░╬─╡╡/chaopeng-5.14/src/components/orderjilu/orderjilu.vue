<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="订单记录" left-arrow @click-left="onClickLeft" fixed />
		<div class="dcvf" v-for="(item,index) in listg" :key="index">
			<div class="jghj">
				<div>
					<div>{{item.payTitle}}</div>
					<div v-if="item.checkupUserType==0">个人购买</div>
					<div v-if="item.checkupUserType==1">团队购买</div>
				</div>
				<div style="color:#a0a0a0;">日期：{{item.updateTime}}</div>
				<div style="color:#ff0000;font-size:0.18rem;">￥{{item.price}}</div>
				<div style="width:25%;margin-left:75%;">
					<div @click="skjhg(item.id)" class="fikuang">查看详情</div>
				</div>
			</div>
		</div>
	</div>	
</template>

<script>
	export default {
		name: 'orderjilu',
		data () {
			return {
				listg:''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			skjhg (id) {
				this.$router.push({name:'ddjl',
					query:{
						id:id
					}
				})
			}
		},
		mounted() {
			this.$axios.post("/user/order/readList", {
				"orderStatus": 1,
				"start": 1,
				"pageSize": 100000,
			}).then((res) => {
				if(res.data.code==0){
					console.log(res.data.data)
					this.listg=res.data.data;
				}
			})
		}
	}
</script>

<style>
	.dcvf {
		width: 100%;
		background: #fff;
	}
	
	.jghj {
		width: 90%;
		margin: 0 auto 0.1rem;
		padding: 0.1rem 0;
		border-bottom:0.01rem solid #e5e5e5;
	}
	
	.jghj>div {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		padding: 0.04rem 0;
	}
	.fikuang{
		width:0.8rem;
		height:0.35rem;
		line-height: 0.35rem;
		text-align: center;
		color:#fff;
		background:#3778ff;
		border-radius:0.05rem;
	}
</style>