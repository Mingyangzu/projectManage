<template>
	<div>
		<van-nav-bar title="个人信息" left-arrow @click-left="onClickLeft" fixed />
		<div style="margin-top:0.46rem;">
			<div style="background: #fff;">
				<div class="lei">
					<div class="xvbs">昵称</div>
					<div><input placeholder="输入昵称" class="input1" v-model="nickname" /></div>
				</div>
				<div class="lei">
					<div class="xvbs">真实姓名</div>
					<div><input placeholder="输入真实姓名" class="input1" v-model="name" /></div>
				</div>
				<div class="lei">
					<div class="xvbs">出生年月</div>
					<div><input placeholder="输入出生年月" class="input1" v-model="nian" type="number" /></div>
				</div>
				<div class="lei">
					<div class="xvbs">性别</div>
					<van-radio-group v-model="radio" class="radios">
						<van-radio name="1">男</van-radio>
						<van-radio name="0">女</van-radio>
					</van-radio-group>
				</div>
				<div class="lei">
					<div class="xvbs">身份证号</div>
					<div><input placeholder="输入身份证号" class="input1" v-model="zheng" /></div>
				</div>
				<div class="address">
					<div>联系地址</div>
					<div><input placeholder="例：北京市朝阳区立水桥北8号" class="inpt" v-model="address" /></div>
				</div>
			</div>
		</div>
		<div class="queren" @click="baocun">保存</div>
	</div>
</template>

<script>
	var idcardReg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
	import { Toast } from 'vant'
	export default {
		name: "Grxx",
		data() {
			return {
				radio: '1',
				nickname: '',
				name: '',
				nian: '',
				zheng: '',
				address: ''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			baocun() {
				if(this.nickname == '' || this.nickname == null) {
					Toast('请输入昵称');
				} else if(this.name == '' || this.name == null) {
					Toast('请输入真实姓名');
				} else if(this.nian == '' || this.nian == null) {
					Toast('请输入出生年月');
				} else if(idcardReg.test(this.zheng)) {
					if(this.address == '' || this.address == null) {
						Toast('请输入联系地址');
					} else {
						this.$axios.post("/user/modify", {
							name: this.name,
							nickName: this.nickname,
							dateOfBirth: this.nian,
							cardId: this.zheng,
							contactAddress: this.address,
							sex: this.radio
						}).then((res) => {
							if(res.data.code == 0) {
								this.$router.push({
									name: 'Grzs'
								})
							}
						})
					}
				} else {
					Toast('请输入正确的身份证号');
				}
			}
		},
		mounted() {
			this.$axios.get("/user/query").then((res) => {
				if(res.data.code == 0) {
					console.log(res)
					var wskj = res.data.data;
					this.nickname = wskj.nickName;
					this.name = wskj.name;
					this.nian = wskj.dateOfBirth;
					this.zheng = wskj.cardId;
					this.address = wskj.contactAddress;
					this.radio = JSON.stringify(wskj.sex);
				}
			})
		}
	}
</script>

<style>
	.hiddenInput {
		display: none;
	}
	
	.lei {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		align-items: center;
		padding: 0.15rem 0;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.tou {
		width: 0.5rem;
		height: 0.5rem;
		border-radius: 50%;
	}
	
	.input1 {
		width:110%;
		border: none;
	}
	
	.xvbs {
		width: 0.68rem;
		margin-right:10%;
	}
	
	.radios {
		width:60%;
		display: flex;
		flex-direction: row;
	}
	
	
	.address {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		padding: 0.15rem 0;
	}
	
	.inpt {
		margin-left: 0;
		padding: 0.2rem 0;
		width: 80%;
		border: none;
	}
	
	.queren {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		color: #fff;
		border-radius: 0.3rem;
		text-align: center;
		background: #3778ff;
		margin: 0.3rem auto;
	}
</style>