<template>
	<div class="can">
		<div class="nian">限时特惠</div>
		<div class="wmp">
			<div v-for="(item,index) in list" :key="index">
				<router-link :to="{name:'Timehui'}" style="color:#000;">
					<div style="width:100%;height:0.9rem;margin:0.03rem 0;">
						<img :src="item.img" style="width:100%;height:100%;border-radius:5px;" />
					</div>
					<div style="margin:0.05rem 0;">{{item.name}}</div>
				</router-link>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Tehui",
		data() {
			return {
				list: [{
						img: 'static/image/discount_01.png',
						name: '无创基因检测'
					},
					{
						img: 'static/image/discount_02.png',
						name: '要事业更要健康'
					},
					{
						img: 'static/image/discount_03.png',
						name: '爸妈健康我们放心'
					},
					{
						img: 'static/image/discount_04.png',
						name: '从健康中延续美丽'
					}
				]
			}
		}
	}
</script>

<style>
	.can {
		width: 100%;
		background: #fff;
		margin: 0.05rem 0;
	}

	.nian {
		position: relative;
		width: 90%;
		left: 5%;
		padding: 0.05rem 0 0;
	}

	.wmp {
		width: 90%;
		padding: 0.1rem 0;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
		text-align: center;
		font-size: 0.12rem;
	}

	.wmp>div {
		width: 47%;
		height: 1.2rem;
	}
</style>
