<template>
	<div style="margin-top:0.46rem;">
		<van-nav-bar title="体检预约" left-arrow @click-left="onClickLeft" fixed />
		<div style="width:100%;background:#fff;" v-if="!tishi">
			<div class="yuyue">
				<div>
					<div class="mnv">预约码</div>
					<div><input placeholder="输入预约码" class="ppt" v-model="yym" /></div>
				</div>
				<div>
					<div class="mnv">手机号码</div>
					<div><input placeholder="输入手机号码" type="number" class="ppt" v-model="phonrd" /></div>
				</div>
				<div>
					<div class="mnv">医院选择</div>
					<div style="display: flex;flex-direction: row;justify-content: space-between;width:70%;align-items: center;" @click="yiyuan">
						<div>{{pdxc}}</div>
						<div>
							<van-icon name="arrow" color="#9e9e9e" size="0.2rem" />
						</div>
					</div>
				</div>
				<div style="border: none;">
					<div class="mnv">体检日期</div>
					<div style="display: flex;flex-direction: row;justify-content: space-between;width:70%;align-items: center;" @click="day">
						<div>{{riqi}}</div>
						<div>
							<van-icon name="arrow" color="#9e9e9e" size="0.2rem" />
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="tijiao" @click="ghfd" v-if="!tishi">提交</div>
		<van-popup v-model="show" position="bottom" :overlay="true" :close-on-click-overlay="true">
			<van-picker :columns="columns" show-toolbar title="医院选择" @change="onChange" @cancel="onCancel" @confirm="onConfirm" />
		</van-popup>
		<van-popup v-model="show1" position="bottom" :overlay="true" :close-on-click-overlay="true">
			<van-datetime-picker v-model="currentDate" type="datetime" @cancel="cancel" @confirm="confirm" :min-date="minDate" />
		</van-popup>
		<div class="dfgtr" v-if="tishi">
			<div class="tishi">
				<img src="static/image/success.png" style="width:100%;height:100%;" />
			</div>
			<div style="margin:0.1rem 0;color:#999999">预约成功</div>
			<div style="margin:0.1rem 0;color:#999999">可在个人中心查看预约历史</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "subscribe",
		data() {
			return {
				show: false,
				show1: false,
				tishi: false,
				pdxc: '点击选择',
				riqi: '点击选择',
				yym: '',
				phonrd: '',
				yyid:'',
				columns: [{
						values: Object.keys(this.$route.query.citys),
						className: 'column1'
					},
					{
						values:this.$route.query.citys['请选择'],
						className: 'column2',
						defaultIndex: 0
					}
				],
				minHour: 1,
				maxHour: 60,
				minDate: new Date(),
				currentDate: new Date()
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			onConfirm(e) {
				this.show = false;
				this.pdxc = e[0] + '-' + e[1];
			},
			onChange(picker, values) { //医院选择
				var getIndexes=picker.getIndexes(1);
				picker.setColumnValues(1, this.$route.query.citys[values[0]]);
				this.$axios.get("/hospital/queryAll").then((res) => {
					if(res.data.code == 0) {
						var data = res.data.data;
						var yiyuan={};
						yiyuan.areaName='请选择';
						var hospitalList=[];
						var zilei={};
						zilei.name='请选择';
						zilei.id='df5';
						hospitalList.push(zilei);
						yiyuan.hospitalList=hospitalList;
						data.unshift(yiyuan);
						this.yyid=data[getIndexes[0]].hospitalList[getIndexes[1]].id;
					}
				})
			},
			onCancel() {
				this.show = false
			},
			yiyuan() {
				this.show = true
			},
			day() {
				this.show1 = true
			},
			cancel() {
				this.show1 = false
			},
			confirm(e) { //选中的体检日期
				var resDate = e.getFullYear() + '-' + (e.getMonth() + 1) + '-' + e.getDate() + ' ' + e.getHours() + ':' + e.getMinutes();
				console.log(resDate)
				this.riqi = resDate;
				this.show1 = false;
			},
			ghfd() { //提交
				var myreg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
				if(this.yym == '') {
					Toast('请输入预约码')
				} else if(myreg.test(this.phonrd)) {
					if(this.riqi == '请选择') {
						Toast('请选择体检日期')
					} else if(this.pdxc == '请选择') {
						Toast('请选择体检医院')
					} else {
						this.$axios.post("/user/appointment/create", {
							"checkCode": this.yym,
							"mobile": this.phonrd,
							"hospitalId":this.yyid,
							"checkTime": this.riqi
						}).then((res) => {
							console.log(res.data)
							if(res.data.code == 0) {
								this.tishi=true;
							}else{
								Toast(res.data.msg)
							}
						})
					}
				} else {
					Toast('请输入正确的手机号')
				}
			}
		},
		mounted () {
			this.$axios.get("/user/query").then((res) => {
				if(res.data.code == 0) {
					
				}
			})
		}
	}
</script>

<style>
	.yuyue {
		width: 90%;
		margin: 0 auto;
	}
	
	.yuyue>div {
		display: flex;
		flex-direction: row;
		border-bottom: 0.01rem solid #e5e5e5;
		align-items: center;
		padding: 0.13rem 0;
	}
	
	.mnv {
		width: 1rem;
	}
	
	.ppt {
		border: none;
	}
	.tijiao{
		width:85%;
		height:0.5rem;
		line-height: 0.5rem;
		background: #057BE3;
		text-align: center;
		color:#fff;
		margin:0.6rem auto;
		border-radius: 0.3rem;
	}
	.dfgtr{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin:1.5rem 0;
	}
	.tishi {
		width: 0.8rem;
		height: 0.8rem;
		margin:0.3rem 0 0.1rem;
	}
</style>