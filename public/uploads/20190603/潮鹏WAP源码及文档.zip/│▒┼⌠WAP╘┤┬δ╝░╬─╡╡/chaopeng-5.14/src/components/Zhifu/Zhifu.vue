<template>
	<div>
		<van-nav-bar title="选择支付方式" left-arrow @click-left="onClickLeft" fixed />
		<div class="zhifu">
			<!--<div class="dpk" v-if="orderId==''">
				<div>
					<div style="font-size:0.16rem;">{{dingdan.payTitle}}</div>
				</div>
				<div style="color:#ff0000;font-size:0.16rem;">{{dingdan.price}}元</div>
			</div>-->
		</div>
		<div class="fang">
			<van-radio-group v-model="radio" style="display: flex;flex-direction: column;">
				<div style="display: flex;flex-direction: row;border-bottom: 0.01rem solid #e5e5e5;">
					<div class="xian"></div>
					<div class="shi">支付方式</div>
				</div>
				<div class="wei" style="border-bottom: 0.01rem solid #e5e5e5;">
					<div>
						<div class="xdf"><img src="static/image/wx.png" /></div>
						<div class="sct">微信支付</div>
					</div>
					<van-radio name="1"></van-radio>
				</div>
				<div class="wei" v-show="bao==0">
					<div>
						<div class="xdf"><img src="static/image/zfb.png" /></div>
						<div class="sct">支付宝支付</div>
					</div>
					<van-radio name="2"></van-radio>
				</div>
			</van-radio-group>
		</div>
		<button class="zhifuk" @click="qrzf" :disabled="isDisable">确认支付</button>
	</div>
</template>

<script>
	import { Toast } from 'vant'
	var mbv;
	var code;
	export default {
		name: "Zhifu",
		data() {
			return {
				radio: '1',
				dingdan:'',
				orderId:'',
				bao: 0,
				isDisable:false
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-2);
			},
			weixinPay(data) {
				console.log("进入支付")
				if(typeof WeixinJSBridge == "undefined") {
					if(document.addEventListener) {
						document.addEventListener('WeixinJSBridgeReady', this.onBridgeReady(data), false);
					} else if(document.attachEvent) {
						document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady(data));
						document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady(data));
					}
				} else {
					this.onBridgeReady(data);
				}
			},
			onBridgeReady(data) {
				var _this=this;
				WeixinJSBridge.invoke(
					'getBrandWCPayRequest', data,
					function(res) {
						mbv = setInterval(() => {
							_this.$axios.post("/wxPay/checkOrderIsPay", {
								"orderId": _this.orderId
							}).then(res => {
								console.log(res)
								if(res.data.code == 0) {
									if(res.data.data == 1) {
										_this.$router.push({
											path: '/user/paySuccess'
										})
										clearInterval(mbv)
									}else{
										console.log("支付失败")
									}
								}
							})
						}, 2000)
					});
			},
			GetQueryString(name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
				var r = window.location.search.substr(1).match(reg);
				if(r != null) return unescape(r[2]);
				return null;
			},
			qrzf() {
				var _this=this;
				_this.isDisable=true;
				if(_this.radio == 1) { //微信支付	
					var ua = navigator.userAgent.toLowerCase();
					if(ua.match(/MicroMessenger/i) == "micromessenger") {   
						code = _this.GetQueryString('code');
						_this.orderId=_this.GetQueryString('state');
						_this.$axios.post("/wxPay/getJsApiConf", {
							"orderId": _this.orderId,
							"code": code
						}).then(res => {
							if(res.data.code == 0) {
								var data = res.data.data;
								console.log(data)
								var list = {};
								list.appId = data.appId;
								list.timeStamp = data.timeStamp;
								list.nonceStr = data.nonceStr;
								list.package = data.packageStr;
								list.signType = data.signType;
								list.paySign = data.paySign;                                                                        
								_this.weixinPay(list);
							}else{
								Toast(res.data.msg)
							}
						})
					} else {
						console.log("浏览器支付")
						_this.$axios.post("/wxPay/unifiedorder", {
							"orderId": _this.orderId
						}).then(res => {
							if(res.data.code == 0) {
								var data = res.data.data;
								mbv = setInterval(() => {
									_this.$axios.post("/wxPay/checkOrderIsPay", {
										"orderId": _this.orderId
									}).then(res => {
										if(res.data.code == 0) {
											if(res.data.data == 1) {
												_this.$router.push({
													path: '/user/paySuccess'
												})
												clearInterval(mbv)
											}
										}
									})
								}, 2000)
								window.open(data, "_self");
							}else{
								Toast(res.data.msg)
							}
						})
					}
				} else { //支付宝支付
					_this.$axios.post("/aliPay/aliTradePagePay", {
						"orderId": _this.orderId
					}).then(res => {
						if(res.data.code == 0) {
							var data = res.data.data;
							window.open(data, "_self");
						}else{
							Toast(res.data.msg)
						}
					})
				}
			}
		},
		mounted() {
			var _this=this;
			if(_this.$route.query.result){
				_this.$axios.post("/user/order/createWaitPayOrder", { //创建订单
					"checkUpIdList": _this.$route.query.result
				}).then(res => {
					if(res.data.code == 0) {
						var dingdan = res.data.data;
						_this.orderId=dingdan.orderId;
						var ua = navigator.userAgent.toLowerCase();
						if(ua.match(/MicroMessenger/i) == "micromessenger") {
							code = _this.GetQueryString('code');
							var appId = "wx8049baaa9d8a4f1b";
							var redirect_uri = 'https%3a%2f%2fwww.chaopengjiankang.com%2fwap%2f%23%2fzhifu';
							var wx_link = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + appId + '&redirect_uri=' + redirect_uri + '&response_type=code&scope=snsapi_base&state='+_this.orderId+'#wechat_redirect';
							window.location.href = wx_link;
							code = _this.GetQueryString('code');
							_this.orderId = _this.GetQueryString('state');
						}
					}else{
						Toast(res.data.msg)
					}
				})	
			}
			if(_this.$route.query.orderId){
				_this.orderId=_this.$route.query.orderId;
				console.log(_this.orderId)
				var ua = navigator.userAgent.toLowerCase();
				if(ua.match(/MicroMessenger/i) == "micromessenger") {
					code = _this.GetQueryString('code');
					var appId = "wx8049baaa9d8a4f1b";
					var redirect_uri = 'https%3a%2f%2fwww.chaopengjiankang.com%2fwap%2f%23%2fzhifu';
					var wx_link = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + appId + '&redirect_uri=' + redirect_uri + '&response_type=code&scope=snsapi_base&state='+_this.orderId+'#wechat_redirect';
					window.location.href = wx_link;
					code = _this.GetQueryString('code');
					_this.orderId = _this.GetQueryString('state');
				}
			}
			var ua = navigator.userAgent.toLowerCase();
			if(ua.match(/MicroMessenger/i) == "micromessenger") {
				_this.bao = 1;
			}
		},
		beforeDestroy () {
			console.log("销毁前清楚定时器")
			clearInterval(mbv)
		}
	}
</script>

<style>
	.zhifu {
		background: #fff;
		margin-top: 0.46rem;
	}
	
	.dpk {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		padding: 0.1rem 0;
	}
	
	.fang {
		background: #fff;
		margin-top: 0.1rem;
	}
	
	.xian {
		width: 0.04rem;
		height: 0.2rem;
		background: #3778ff;
		margin: 0.1rem 0.1rem 0;
	}
	
	.shi {
		padding: 0.1rem 0;
	}
	
	.wei {
		width: 90%;
		margin: 0 auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		padding: 0.2rem 0;
	}
	
	.wei>div {
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: center;
	}
	
	.xdf {
		width: 0.3rem;
		height: 0.3rem;
	}
	
	.sct {
		margin-left: 0.2rem;
	}
	
	.zhifuk {
		width: 90%;
		height: 0.5rem;
		line-height: 0.5rem;
		background: #cb5b17;
		color: #fff;
		text-align: center;
		border:none;
		border-radius: 0.3rem;
		position: fixed;
		bottom: 30%;
		left: 5%;
	}
</style>