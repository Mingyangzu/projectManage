<template>
	<div style="background:#f6f6f6;">
		<van-nav-bar title="套餐详情" left-arrow @click-left="onClickLeft" fixed />
		<div style="background: #fff;margin-top:0.5rem">
			<div class="ehg">
				<div class="wvs">
					<div style="color:#494949;font-size:0.16rem;">{{xiangqing.name}}</div>
					<div class="money">
						<div style="color:#ff0000;font-size:0.16rem;">￥{{xiangqing.price}}起</div>
						<div style="color:#999999;margin-left:-0.7rem;text-decoration:line-through">￥{{xiangqing.originalPrice}}</div>
					</div>
				</div>
			</div>
		</div>
		<div class="mian">
			<div>
				<div class="kjh">
					<img src="static/image/tijian1.png" />
				</div>
				<div style="padding:0.05rem 0;">特质营养早餐</div>
				<div style="color:#999999;">免费</div>
			</div>
			<div>
				<div class="kjh">
					<img src="static/image/tijian2.png" />
				</div>
				<div style="padding:0.05rem 0;">检中医护免费查询</div>
				<div style="color:#999999;">现场</div>
			</div>
			<div>
				<div class="kjh">
					<img src="static/image/tijian3.png" />
				</div>
				<div style="padding:0.05rem 0;">主检医生总结报告</div>
				<div style="color:#999999;">10日</div>
			</div>
		</div>
		<div class="taocanx">
			<div style="width:90%;margin:0 auto 0.5rem;">
				<div style="padding:0.08rem 0;">套餐详情</div>
				<div class="mun" v-if="id==1">
					<!--套餐a-->
					<div class="touh">临床科室检查项目</div>
					<div>静脉抽血</div>
					<div style="color:#a1a1a1;">采血器、真空采血管安全、方便、无菌、无交叉感染</div>
					<div class="xiangm">
						<div>注意事项：空腹采血</div>
						<div>项目数：1</div>
					</div>
					<div>一般检查</div>
					<div style="color:#a1a1a1;">了解身体基础数据，血压变化，是否超重或肥胖</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：4</div>
					</div>
					<div>内科</div>
					<div style="color:#a1a1a1;">通过视、触、叩、听检查心、肺、肝、脾等重要脏器的基本状况，发现常见疾病的相关征兆，或初步排除常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div>外科</div>
					<div style="color:#a1a1a1;">检查皮肤、甲状腺、脊柱四肢、前列腺、外生殖器等重要脏器基本情况，发现常见外科疾病的相关征兆，或初步排除外科常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：8</div>
					</div>
					<div>妇科、内诊</div>
					<div style="color:#a1a1a1;">检查生殖系统及附件有无异常，有无细菌感染、霉菌、滴虫等</div>
					<div class="xiangm">
						<div>注意事项：女性检项、未婚不宜</div>
						<div>项目数：5</div>
					</div>
					<div>视力色觉</div>
					<div style="color:#a1a1a1;">检查视力及辨别各种颜色的能力</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：2</div>
					</div>
					<div>外眼、眼底检查</div>
					<div style="color:#a1a1a1;">检查眼睑、泪囊、结膜、眼球是否存在异常情况</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：5</div>
					</div>
					<div>耳鼻喉科</div>
					<div style="color:#a1a1a1;">检查听力是否正常；检查耳廓、外耳道、鼓膜有无异常，乳突有无压痛；检查鼻、咽、喉、扁桃体有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：13</div>
					</div>
					<div>口腔科</div>
					<div style="color:#a1a1a1;">检查有无龋齿、残根、缺齿、义齿；口腔黏膜及腺体有无异常；牙龈、牙周及下颌关节有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：6</div>
					</div>
					<div>心电图</div>
					<div style="color:#a1a1a1;">发现有无心律失常、缺血性心脏病、心肌病变等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div class="touh">检验科临检项目</div>
					<div>血常规27项</div>
					<div style="color:#a1a1a1;">白细胞增加或减少，根据白细胞分类计数，初步确定为细菌感染或病毒性感染或为白血病；白细胞分类值，有助于相关疾病的诊断与治疗；贫血或失血都会影响红细胞数目：升高时可能患红细胞增多症或地中海型贫血；低于正常值时可能为贫血；了解血液浓缩有无浓缩；血小板数目的变化作为协助检查疾病的参数；检查有无出/凝血异常、出血性疾病；血小板形态有无异常等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：19</div>
					</div>
					<div>尿常规11项</div>
					<div style="color:#a1a1a1;">检查有无有无泌尿系统疾病和糖尿病、急慢性肾病、肾炎等。可间接检查与肾脏无关的代谢障碍或疾病等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：11</div>
					</div>
					<div class="touh">检验科生化项目</div>
					<div>空腹葡萄糖(GLU)</div>
					<div style="color:#a1a1a1;">有无糖尿病及是否低血糖；筛检糖尿病、了解血糖控制状况最基本方法</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">血脂4项</div>
					<div>总胆固醇(CHO)</div>
					<div style="color:#a1a1a1;">体内最具代表性的脂肪物质，动脉粥样硬化斑块的主要来源。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>甘油三酯(TG)</div>
					<div style="color:#a1a1a1;">脂肪代谢的主要物质，其数值偏高是一种常见的高脂血症。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>高密度脂蛋白胆固醇(HDL-C)</div>
					<div style="color:#a1a1a1;">能将胆固醇从周围组织运出到肝脏代谢，对血管有保护作用，防止动脉粥样硬化。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>低密度脂蛋白胆固醇(LDL-C)</div>
					<div style="color:#a1a1a1;">能转运胆固醇至周围组织，动脉内膜沉积大量脂质，LDL过高是血管硬化的危险因素。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肝功</div>
					<div>丙氨酸氨基转氨酶（ALT)</div>
					<div style="color:#a1a1a1;">丙氨酸氨基转氨酶是一种催化人体蛋白质氨基酸在体内转化的酶，广泛存在于人体各种组织、器官、肌肉、骨骼中，以肝细胞中最多，因此是判断肝脏病变程度的重要指标。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>天门冬氨酸氨基转氨酶（AST）</div>
					<div style="color:#a1a1a1;">血清天门冬氨酸氨基转移酶心肌细胞中含量较高，当心机细胞受到损伤时，大量释放人血，常用于心脏疾病的诊断。各种肝病AST/ALT比值大于1，肾炎、肺炎时亦可轻度增高。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肾功能</div>
					<div>尿素氮(BUN)</div>
					<div style="color:#a1a1a1;">肾脏虑过代谢的最终产物，当肾功能损害时，体内代谢产物堆积，此时血清中尿素氮数值升高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>肌酐（CRE)</div>
					<div style="color:#a1a1a1;">检测肾脏的排泄功能</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>尿酸(UA)</div>
					<div style="color:#a1a1a1;">饮酒过量、糖尿病、痛风、肾炎、铅中毒、副甲状腺机能亢进等尿酸会偏高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肿瘤系列检测</div>
					<div>特制营养早餐</div>
					<div style="color:#a1a1a1;">特制营养早餐</div>
					<div class="xiangm">
						<div>注意事项：空腹检项、检查完毕</div>
						<div>项目数：免费</div>
					</div>
					<div>检后服务</div>
					<div style="color:#a1a1a1;">检中医护免费咨询、主检医生汇总体检报告，并出具健康管理报告。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：现场、检后10日</div>
					</div>
				</div>
				<div class="mun" v-if="id==2">
					<!--套餐b-->
					<div class="touh">临床科室检查项目</div>
					<div>静脉抽血</div>
					<div style="color:#a1a1a1;">采血器、真空采血管安全、方便、无菌、无交叉感染</div>
					<div class="xiangm">
						<div>注意事项：空腹采血</div>
						<div>项目数：1</div>
					</div>
					<div>一般检查</div>
					<div style="color:#a1a1a1;">了解身体基础数据，血压变化，是否超重或肥胖</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：4</div>
					</div>
					<div>内科</div>
					<div style="color:#a1a1a1;">通过视、触、叩、听检查心、肺、肝、脾等重要脏器的基本状况，发现常见疾病的相关征兆，或初步排除常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div>外科</div>
					<div style="color:#a1a1a1;">检查皮肤、甲状腺、脊柱四肢、前列腺、外生殖器等重要脏器基本情况，发现常见外科疾病的相关征兆，或初步排除外科常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：8</div>
					</div>
					<div>内诊</div>
					<div style="color:#a1a1a1;">检查生殖系统及附件有无异常，有无细菌感染、霉菌、滴虫等</div>
					<div class="xiangm">
						<div>注意事项：女性检项、未婚不宜</div>
						<div>项目数：5</div>
					</div>
					<div>宫颈TCT</div>
					<div style="color:#a1a1a1;">TCT是国际上使用最广泛的一种宫颈病变筛查技术。对宫颈癌细胞检出率为100%，同时还能发现部分癌前病变，微生物感染如霉菌、滴虫、衣原体等。</div>
					<div class="xiangm">
						<div>注意事项：女性检项、未婚不宜</div>
						<div>项目数：1</div>
					</div>
					<div>视力色觉</div>
					<div style="color:#a1a1a1;">检查视力及辨别各种颜色的能力</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：2</div>
					</div>
					<div>外眼、眼底检查</div>
					<div style="color:#a1a1a1;">检查眼睑、泪囊、结膜、眼球是否存在异常情况</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：5</div>
					</div>
					<div>裂隙灯</div>
					<div style="color:#a1a1a1;">检查眼睑、结膜、巩膜、角膜、前房、虹膜、瞳孔、晶状体及玻璃体，确定病变的位置、性质、大小及其深度</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：5</div>
					</div>
					<div>耳鼻喉科</div>
					<div style="color:#a1a1a1;">检查听力是否正常；检查耳廓、外耳道、鼓膜有无异常，乳突有无压痛；检查鼻、咽、喉、扁桃体有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：13</div>
					</div>
					<div>口腔科</div>
					<div style="color:#a1a1a1;">检查有无龋齿、残根、缺齿、义齿；口腔黏膜及腺体有无异常；牙龈、牙周及下颌关节有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：6</div>
					</div>
					<div>心电图</div>
					<div style="color:#a1a1a1;">发现有无心律失常、缺血性心脏病、心肌病变等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div class="touh">放射科室检查项目</div>
					<div>X光室—胸部正位</div>
					<div style="color:#a1a1a1;">检查肺脏结构是否正常，有无异常症像</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>X光室—颈椎侧位</div>
					<div style="color:#a1a1a1;">观察颈的双侧是否对称、椎体侧缘增生、生理弯曲度是否正常、各椎间隙是否等宽、有无变形或先天性畸形</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>骨密度</div>
					<div style="color:#a1a1a1;">了解有无骨质疏松及疏松程度，预测骨折的危险性。</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>上腹彩超</div>
					<div style="color:#a1a1a1;">检查肝、胆、胰、脾、双肾结构及形态是否正常</div>
					<div class="xiangm">
						<div>注意事项：空腹检查</div>
						<div>项目数：5</div>
					</div>
					<div>乳腺彩超</div>
					<div style="color:#a1a1a1;">检查乳腺小叶增生、炎症、囊肿、纤维瘤及乳腺癌等疾病</div>
					<div class="xiangm">
						<div>注意事项：女性检项</div>
						<div>项目数：1</div>
					</div>
					<div>前列腺超声检查</div>
					<div style="color:#a1a1a1;">利用超声波作为探测和负载信息的载体或媒介，发现和诊断前列腺疾病，如：炎症、钙化、增生、肿瘤等。</div>
					<div class="xiangm">
						<div>注意事项：仅限男性</div>
						<div>项目数：1</div>
					</div>
					<div>妇科超声检查</div>
					<div style="color:#a1a1a1;">利用超声波作为探测和负载信息的载体或媒介，发现和诊断妇科疾病，常见的如：卵巢囊肿、子宫肌瘤、子宫体癌、绒毛膜上皮癌等。</div>
					<div class="xiangm">
						<div>注意事项：仅限女性</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">检验科临检项目</div>
					<div>血常规27项</div>
					<div style="color:#a1a1a1;">白细胞增加或减少，根据白细胞分类计数，初步确定为细菌感染或病毒性感染或为白血病；白细胞分类值，有助于相关疾病的诊断与治疗；贫血或失血都会影响红细胞数目：升高时可能患红细胞增多症或地中海型贫血；低于正常值时可能为贫血；了解血液浓缩有无浓缩；血小板数目的变化作为协助检查疾病的参数；检查有无出/凝血异常、出血性疾病；血小板形态有无异常等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：19</div>
					</div>
					<div>尿常规11项</div>
					<div style="color:#a1a1a1;">检查有无有无泌尿系统疾病和糖尿病、急慢性肾病、肾炎等。可间接检查与肾脏无关的代谢障碍或疾病等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：11</div>
					</div>
					<div class="touh">检验科生化项目</div>
					<div>空腹葡萄糖(GLU)</div>
					<div style="color:#a1a1a1;">有无糖尿病及是否低血糖；筛检糖尿病、了解血糖控制状况最基本方法</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">血脂4项</div>
					<div>总胆固醇(CHO)</div>
					<div style="color:#a1a1a1;">体内最具代表性的脂肪物质，动脉粥样硬化斑块的主要来源。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>甘油三酯(TG)</div>
					<div style="color:#a1a1a1;">脂肪代谢的主要物质，其数值偏高是一种常见的高脂血症。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>高密度脂蛋白胆固醇(HDL-C)</div>
					<div style="color:#a1a1a1;">能将胆固醇从周围组织运出到肝脏代谢，对血管有保护作用，防止动脉粥样硬化。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>低密度脂蛋白胆固醇(LDL-C)</div>
					<div style="color:#a1a1a1;">能转运胆固醇至周围组织，动脉内膜沉积大量脂质，LDL过高是血管硬化的危险因素。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肝功</div>
					<div>丙氨酸氨基转氨酶（ALT)</div>
					<div style="color:#a1a1a1;">丙氨酸氨基转氨酶是一种催化人体蛋白质氨基酸在体内转化的酶，广泛存在于人体各种组织、器官、肌肉、骨骼中，以肝细胞中最多，因此是判断肝脏病变程度的重要指标。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>天门冬氨酸氨基转氨酶（AST）</div>
					<div style="color:#a1a1a1;">血清天门冬氨酸氨基转移酶心肌细胞中含量较高，当心机细胞受到损伤时，大量释放人血，常用于心脏疾病的诊断。各种肝病AST/ALT比值大于1，肾炎、肺炎时亦可轻度增高。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肾功能</div>
					<div>尿素氮(BUN)</div>
					<div style="color:#a1a1a1;">肾脏虑过代谢的最终产物，当肾功能损害时，体内代谢产物堆积，此时血清中尿素氮数值升高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>肌酐（CRE)</div>
					<div style="color:#a1a1a1;">检测肾脏的排泄功能</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>尿酸(UA)</div>
					<div style="color:#a1a1a1;">饮酒过量、糖尿病、痛风、肾炎、铅中毒、副甲状腺机能亢进等尿酸会偏高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肿瘤系列检测</div>
					<div>特制营养早餐</div>
					<div style="color:#a1a1a1;">特制营养早餐</div>
					<div class="xiangm">
						<div>注意事项：空腹检项、检查完毕</div>
						<div>项目数：免费</div>
					</div>
					<div>检后服务</div>
					<div style="color:#a1a1a1;">检中医护免费咨询、主检医生汇总体检报告，并出具健康管理报告。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：现场、检后10日</div>
					</div>
				</div>
				<div class="mun" v-if="id==3">
					<!--套餐c-->
					<div class="touh">临床科室检查项目</div>
					<div>静脉抽血</div>
					<div style="color:#a1a1a1;">采血器、真空采血管安全、方便、无菌、无交叉感染</div>
					<div class="xiangm">
						<div>注意事项：空腹采血</div>
						<div>项目数：1</div>
					</div>
					<div>一般检查</div>
					<div style="color:#a1a1a1;">了解身体基础数据，血压变化，是否超重或肥胖</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：4</div>
					</div>
					<div>内科</div>
					<div style="color:#a1a1a1;">通过视、触、叩、听检查心、肺、肝、脾等重要脏器的基本状况，发现常见疾病的相关征兆，或初步排除常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div>外科</div>
					<div style="color:#a1a1a1;">检查皮肤、甲状腺、脊柱四肢、前列腺、外生殖器等重要脏器基本情况，发现常见外科疾病的相关征兆，或初步排除外科常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：8</div>
					</div>
					<div>内诊</div>
					<div style="color:#a1a1a1;">检查生殖系统及附件有无异常，有无细菌感染、霉菌、滴虫等</div>
					<div class="xiangm">
						<div>注意事项：女性检项、未婚不宜</div>
						<div>项目数：5</div>
					</div>
					<div>宫颈TCT</div>
					<div style="color:#a1a1a1;">TCT是国际上使用最广泛的一种宫颈病变筛查技术。对宫颈癌细胞检出率为100%，同时还能发现部分癌前病变，微生物感染如霉菌、滴虫、衣原体等。</div>
					<div class="xiangm">
						<div>注意事项：女性检项、未婚不宜</div>
						<div>项目数：1</div>
					</div>
					<div>视力色觉</div>
					<div style="color:#a1a1a1;">检查视力及辨别各种颜色的能力</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：2</div>
					</div>
					<div>外眼、眼底检查</div>
					<div style="color:#a1a1a1;">检查眼睑、泪囊、结膜、眼球是否存在异常情况</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：5</div>
					</div>
					<div>裂隙灯</div>
					<div style="color:#a1a1a1;">检查眼睑、结膜、巩膜、角膜、前房、虹膜、瞳孔、晶状体及玻璃体，确定病变的位置、性质、大小及其深度</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：5</div>
					</div>
					<div>耳鼻喉科</div>
					<div style="color:#a1a1a1;">检查听力是否正常；检查耳廓、外耳道、鼓膜有无异常，乳突有无压痛；检查鼻、咽、喉、扁桃体有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：13</div>
					</div>
					<div>口腔科</div>
					<div style="color:#a1a1a1;">检查有无龋齿、残根、缺齿、义齿；口腔黏膜及腺体有无异常；牙龈、牙周及下颌关节有无异常</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：6</div>
					</div>
					<div>心电图</div>
					<div style="color:#a1a1a1;">发现有无心律失常、缺血性心脏病、心肌病变等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div class="touh">放射科室检查项目</div>
					<div>X光室—胸部正位</div>
					<div style="color:#a1a1a1;">检查肺脏结构是否正常，有无异常症像</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>X光室—颈椎侧位</div>
					<div style="color:#a1a1a1;">观察颈的双侧是否对称、椎体侧缘增生、生理弯曲度是否正常、各椎间隙是否等宽、有无变形或先天性畸形</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>骨密度</div>
					<div style="color:#a1a1a1;">了解有无骨质疏松及疏松程度，预测骨折的危险性。</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div>上腹彩超</div>
					<div style="color:#a1a1a1;">检查肝、胆、胰、脾、双肾结构及形态是否正常</div>
					<div class="xiangm">
						<div>注意事项：空腹检查</div>
						<div>项目数：5</div>
					</div>
					<div>乳腺彩超</div>
					<div style="color:#a1a1a1;">检查乳腺小叶增生、炎症、囊肿、纤维瘤及乳腺癌等疾病</div>
					<div class="xiangm">
						<div>注意事项：女性检项</div>
						<div>项目数：1</div>
					</div>
					<div>前列腺超声检查</div>
					<div style="color:#a1a1a1;">利用超声波作为探测和负载信息的载体或媒介，发现和诊断前列腺疾病，如：炎症、钙化、增生、肿瘤等。</div>
					<div class="xiangm">
						<div>注意事项：仅限男性</div>
						<div>项目数：1</div>
					</div>
					<div>妇科超声检查</div>
					<div style="color:#a1a1a1;">利用超声波作为探测和负载信息的载体或媒介，发现和诊断妇科疾病，常见的如：卵巢囊肿、子宫肌瘤、子宫体癌、绒毛膜上皮癌等。</div>
					<div class="xiangm">
						<div>注意事项：仅限女性</div>
						<div>项目数：1</div>
					</div>
					<div>双颈动脉彩超</div>
					<div style="color:#a1a1a1;">检查颈总动脉、颈内动脉有无狭窄及动脉粥样硬化斑块</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>甲状腺彩超</div>
					<div style="color:#a1a1a1;">发现病变如：甲状腺炎、甲状腺机能亢进、单纯性甲状腺肿结节性、甲状腺囊肿、甲状腺瘤、甲状腺血管瘤等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">检验科临检项目</div>
					<div>血常规27项</div>
					<div style="color:#a1a1a1;">白细胞增加或减少，根据白细胞分类计数，初步确定为细菌感染或病毒性感染或为白血病；白细胞分类值，有助于相关疾病的诊断与治疗；贫血或失血都会影响红细胞数目：升高时可能患红细胞增多症或地中海型贫血；低于正常值时可能为贫血；了解血液浓缩有无浓缩；血小板数目的变化作为协助检查疾病的参数；检查有无出/凝血异常、出血性疾病；血小板形态有无异常等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：19</div>
					</div>
					<div>尿常规11项</div>
					<div style="color:#a1a1a1;">检查有无有无泌尿系统疾病和糖尿病、急慢性肾病、肾炎等。可间接检查与肾脏无关的代谢障碍或疾病等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：11</div>
					</div>
					<div>幽门螺旋杆菌抗体IgM(HP-AbIgM)</div>
					<div style="color:#a1a1a1;">主要用于胃炎、胃溃疡、胃癌的早期筛查</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">检验科生化项目</div>
					<div>空腹葡萄糖(GLU)</div>
					<div style="color:#a1a1a1;">有无糖尿病及是否低血糖；筛检糖尿病、了解血糖控制状况最基本方法</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">血脂4项</div>
					<div>总胆固醇(CHO)</div>
					<div style="color:#a1a1a1;">体内最具代表性的脂肪物质，动脉粥样硬化斑块的主要来源。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>甘油三酯(TG)</div>
					<div style="color:#a1a1a1;">脂肪代谢的主要物质，其数值偏高是一种常见的高脂血症。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>高密度脂蛋白胆固醇(HDL-C)</div>
					<div style="color:#a1a1a1;">能将胆固醇从周围组织运出到肝脏代谢，对血管有保护作用，防止动脉粥样硬化。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>低密度脂蛋白胆固醇(LDL-C)</div>
					<div style="color:#a1a1a1;">能转运胆固醇至周围组织，动脉内膜沉积大量脂质，LDL过高是血管硬化的危险因素。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肝功</div>
					<div>丙氨酸氨基转氨酶（ALT)</div>
					<div style="color:#a1a1a1;">丙氨酸氨基转氨酶是一种催化人体蛋白质氨基酸在体内转化的酶，广泛存在于人体各种组织、器官、肌肉、骨骼中，以肝细胞中最多，因此是判断肝脏病变程度的重要指标。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>天门冬氨酸氨基转氨酶（AST）</div>
					<div style="color:#a1a1a1;">血清天门冬氨酸氨基转移酶心肌细胞中含量较高，当心机细胞受到损伤时，大量释放人血，常用于心脏疾病的诊断。各种肝病AST/ALT比值大于1，肾炎、肺炎时亦可轻度增高。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肾功能</div>
					<div>尿素氮(BUN)</div>
					<div style="color:#a1a1a1;">肾脏虑过代谢的最终产物，当肾功能损害时，体内代谢产物堆积，此时血清中尿素氮数值升高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>肌酐（CRE)</div>
					<div style="color:#a1a1a1;">检测肾脏的排泄功能</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>尿酸(UA)</div>
					<div style="color:#a1a1a1;">饮酒过量、糖尿病、痛风、肾炎、铅中毒、副甲状腺机能亢进等尿酸会偏高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肿瘤系列检测</div>
					<div>特制营养早餐</div>
					<div style="color:#a1a1a1;">特制营养早餐</div>
					<div class="xiangm">
						<div>注意事项：空腹检项、检查完毕</div>
						<div>项目数：免费</div>
					</div>
					<div>检后服务</div>
					<div style="color:#a1a1a1;">检中医护免费咨询、主检医生汇总体检报告，并出具健康管理报告。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：现场、检后10日</div>
					</div>
				</div>
				<div class="mun" v-if="id==4">
					<!--入职体检-->
					<div class="touh">临床科室检查项目</div>
					<div>静脉抽血</div>
					<div style="color:#a1a1a1;">采血器、真空采血管安全、方便、无菌、无交叉感染</div>
					<div class="xiangm">
						<div>注意事项：空腹采血</div>
						<div>项目数：1</div>
					</div>
					<div>一般检查</div>
					<div style="color:#a1a1a1;">了解身体基础数据，血压变化，是否超重或肥胖</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：4</div>
					</div>
					<div>外科</div>
					<div style="color:#a1a1a1;">检查皮肤、甲状腺、脊柱四肢、前列腺、外生殖器等重要脏器基本情况，发现常见外科疾病的相关征兆，或初步排除外科常见疾病</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：8</div>
					</div>
					<div>视力色觉</div>
					<div style="color:#a1a1a1;">检查视力及辨别各种颜色的能力</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：2</div>
					</div>
					<div>心电图</div>
					<div style="color:#a1a1a1;">发现有无心律失常、缺血性心脏病、心肌病变等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：12</div>
					</div>
					<div class="touh">放射科室检查项目</div>
					<div>X光室—胸部正位</div>
					<div style="color:#a1a1a1;">检查肺脏结构是否正常，有无异常症像</div>
					<div class="xiangm">
						<div>注意事项：怀孕勿查</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">检验科临检项目</div>
					<div>血常规27项</div>
					<div style="color:#a1a1a1;">白细胞增加或减少，根据白细胞分类计数，初步确定为细菌感染或病毒性感染或为白血病；白细胞分类值，有助于相关疾病的诊断与治疗；贫血或失血都会影响红细胞数目：升高时可能患红细胞增多症或地中海型贫血；低于正常值时可能为贫血；了解血液浓缩有无浓缩；血小板数目的变化作为协助检查疾病的参数；检查有无出/凝血异常、出血性疾病；血小板形态有无异常等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：19</div>
					</div>
					<div>尿常规11项</div>
					<div style="color:#a1a1a1;">检查有无有无泌尿系统疾病和糖尿病、急慢性肾病、肾炎等。可间接检查与肾脏无关的代谢障碍或疾病等</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：11</div>
					</div>
					<div>幽门螺旋杆菌抗体IgM(HP-AbIgM)</div>
					<div style="color:#a1a1a1;">主要用于胃炎、胃溃疡、胃癌的早期筛查</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">检验科生化项目</div>
					<div>空腹葡萄糖(GLU)</div>
					<div style="color:#a1a1a1;">有无糖尿病及是否低血糖；筛检糖尿病、了解血糖控制状况最基本方法</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">血脂4项</div>
					<div>总胆固醇(CHO)</div>
					<div style="color:#a1a1a1;">体内最具代表性的脂肪物质，动脉粥样硬化斑块的主要来源。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>甘油三酯(TG)</div>
					<div style="color:#a1a1a1;">脂肪代谢的主要物质，其数值偏高是一种常见的高脂血症。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肝功</div>
					<div>丙氨酸氨基转氨酶（ALT)</div>
					<div style="color:#a1a1a1;">丙氨酸氨基转氨酶是一种催化人体蛋白质氨基酸在体内转化的酶，广泛存在于人体各种组织、器官、肌肉、骨骼中，以肝细胞中最多，因此是判断肝脏病变程度的重要指标。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肾功能</div>
					<div>尿素氮(BUN)</div>
					<div style="color:#a1a1a1;">肾脏虑过代谢的最终产物，当肾功能损害时，体内代谢产物堆积，此时血清中尿素氮数值升高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>肌酐（CRE)</div>
					<div style="color:#a1a1a1;">检测肾脏的排泄功能</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div>尿酸(UA)</div>
					<div style="color:#a1a1a1;">饮酒过量、糖尿病、痛风、肾炎、铅中毒、副甲状腺机能亢进等尿酸会偏高</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：1</div>
					</div>
					<div class="touh">肿瘤系列检测</div>
					<div>特制营养早餐</div>
					<div style="color:#a1a1a1;">特制营养早餐</div>
					<div class="xiangm">
						<div>注意事项：空腹检项、检查完毕</div>
						<div>项目数：免费</div>
					</div>
					<div>检后服务</div>
					<div style="color:#a1a1a1;">检中医护免费咨询、主检医生汇总体检报告，并出具健康管理报告。</div>
					<div class="xiangm">
						<div>注意事项：</div>
						<div>项目数：现场、检后10日</div>
					</div>
				</div>
				<div class="mun" v-if="id==5">
					<!--职业病体检-->
					<div class="touh">苯、甲苯、二甲苯作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：117元
					</div>
					<div class="touh">噪声作业（岗前）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 心电图20元 个体报告结论费 10元 纯音听阈测试40元 全项血常规20元 尿常规10元 血清ALT 4元 采样费4元 材料费9元 合计：137元
					</div>
					<div class="touh">噪声作业（在岗期间、离岗）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 心电图20元 个体报告结论费 10元 纯音听阈测试40元</div>
					<div>自检项目</div>
					<div style="color:#a1a1a1;">全项血常规20元 尿常规10元 血清ALT 4元 采样费4元 材料费9元</div>
					<div class="touh">无机粉尘或有机粉尘作业（岗前）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT4元 心电图20元 DR胸片85元 肺功能45元 个体报告结论费 10元 采样费4元 材料费9元 合计：217元
					</div>
					<div class="touh">无机粉尘或有机粉尘作业（在岗期间、离岗）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 心电图20元 DR胸片85元 肺功能45元 个体报告结论费 10元 </div>
					<div>选检项目</div>
					<div class="touh">硫化氢作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经系统常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：97元 </div>
					<div class="touh">氮氧化物、氯气、氨、二氧化硫、酸、碱作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 个体报告结论费 10元 采样费4元 材料费9元 合计：217元
					</div>
					<div class="touh">无机粉尘或有机粉尘、紫外辐射作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科检查10元 眼科及眼底检查20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 个体报告结论费 10元 采样费4元 材料费9元 合计：247元
					</div>
					<div class="touh">无机粉尘、锰及其无机化合物、氮氧化物、一氧化碳、紫外辐射作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经科常规检查10元 皮肤科检查10元 眼科及眼底检查20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 个体报告结论费 10元 采样费4元 材料费9元 合计：257元
					</div>
					<div class="touh">无机粉尘、锰及其无机化合物、氮氧化物、一氧化碳、紫外辐射、噪声作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经科常规检查10元 皮肤科检查10元 耳科常规检查10元 眼科及眼底检查20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 纯音听阈测试40元个体报告结论费 10元 采样费4元 材料费9元 合计：307元
					</div>
					<div class="touh">苯、甲苯、二甲苯、噪声作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 肝脾B超 30元 纯音听阈测试40元 个体报告结论费 10元 采样费4元 材料费9元 合计：167元
					</div>
					<div class="touh">无机粉尘或有机粉尘、苯、甲苯、二甲苯作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：247元
					</div>
					<div class="touh">无机粉尘或有机粉尘、噪声作业（岗前）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 心电图20元 DR胸片85元 肺功能45元 纯音听阈测试40元 个体报告结论费 10元 全项血常规20元 尿常规10元 血清ALT 4元 采样费4元 材料费9元 合计：267元
					</div>
					<div class="touh">无机粉尘或有机粉尘、噪声作业（在岗期间、离岗）</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 心电图20元 DR胸片85元 肺功能45元 纯音听阈测试40元 个体报告结论费 10元</div>
					<div>选检项目</div>
					<div style="color:#a1a1a1;">全项血常规20元 尿常规10元 血清ALT 4元 采样费4元 材料费9元</div>
					<div class="touh">无机粉尘或有机粉尘、噪声、苯、甲苯、二甲苯作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 DR胸片85元 肺功能45元 纯音听阈测试40元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：297元 </div>
					<div class="touh">高温作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 血糖8元 个体报告结论费 10元 采样费4元 材料费9元 合计：95元
					</div>
					<div class="touh">高处</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 耳科常规检查10元 外科检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：107元
					</div>
					<div class="touh">电工作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经系统常规检查10元 外科检查10元 耳科常规检查10元 眼科及视力及辨色力20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：137元
					</div>
					<div class="touh">紫外线、微波作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科常规检查10元 眼科及眼底检查20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：117元
					</div>
					<div class="touh">微波作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经科常规检查10元 眼科及眼底检查20元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：117元
					</div>
					<div class="touh">铅及其无机化合物</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经系统常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 血铅100元 个体报告结论费 10元 采样费4元 材料费9元 合计：197元
					</div>
					<div class="touh">甲醇作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经系统常规检查10元 眼科检查20元 全项血常规20元 尿常规10元 肝功能6项30元 心电图20元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：173元
					</div>
					<div class="touh">驾驶员作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 纯音听阈测试40元 视力及辨色力10元 眼底检查20元 高千伏胸片38元 个体报告结论费 10元 采样费4元 材料费9元 合计：195元
					</div>
					<div class="touh">汽油作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科常规检查10元 神经科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 血糖8元 个体报告结论费 10元 采样费4元 材料费9元 合计：115元
					</div>
					<div class="touh">苯系物、汽油作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科常规检查10元 神经科常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 血糖8元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：145元
					</div>
					<div class="touh">无机粉尘、苯系物、锡化合物作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科常规检查10元 神经系统常规检查10元 全项血常规20元 尿常规10元 肝功能6项30元 血清电解质16元 心电图20元 DR胸片85元 肺功能45元 肝脾B超 30元 个体报告结论费 10元 采样费4元 材料费9元 合计：309元
					</div>
					<div class="touh">铅及其无机化合物+锡化合物作业</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 皮肤科常规检查10元 神经系统常规检查10元 全项血常规20元 尿常规10元 肝功能6项30元 血清电解质16元 心电图20元 血铅100元 个体报告结论费 10元 采样费4元 材料费9元 合计：249元
					</div>
					<div class="touh">氰及腈类化合物</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">内科常规检查10元 神经系统常规检查10元 全项血常规20元 尿常规10元 血清ALT 4元 心电图20元 个体报告结论费 10元 采样费4元 材料费9元 合计：97元
					</div>
				</div>
				<div class="mun" v-if="id==6">
					<!--健康证A套餐-->
					<div class="touh">体检项目</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">细菌性痢疾、伤寒和副伤寒、病毒性肝炎（甲肝、戊肝）、活动性肺结核、化脓性或渗出性皮肤病、手部真菌感染性疾病、手癣、指甲癣、手部湿疹、手部的银屑或者鳞屑</div>
				</div>
				<div class="mun" v-if="id==7">
					<!--健康证B套餐-->
					<div class="touh">体检项目</div>
					<div>必检项目</div>
					<div style="color:#a1a1a1;">'细菌性痢疾、伤寒和副伤寒、霍乱、阿米巴性痢疾、病毒性肝炎（甲肝、戊肝）、活动性肺结核、化脓性或渗出性皮肤病、手部真菌感染性疾病、手癣、指甲癣、手部湿疹、手部的银屑或者鳞屑</div>
				</div>
			</div>
		</div>
		<div class="footer">
			<div @click="shoopteam" style="color:#fff;background: #3778ff;">
				团队购买
			</div>
			<div @click="shoopgr" style="color:#fff;background: #cb5b17;">
				个人购买
			</div>
		</div>
	</div>
</template>

<script>
	import { Toast } from 'vant';
	export default {
		name: "Xiang",
		data() {
			return {
				id: sessionStorage.getItem("id"),
				xiangqing: ''
			}
		},
		methods: {
			onClickLeft() {
				this.$router.go(-1);
			},
			shoopteam() { //团队购买
				this.$axios.get("/user/query").then((res) => {
					if(res.data.code == 0) {
						this.$router.push({
							name: 'Team',
							query: {
								id: this.id
							}
						})
					}
				})
			},
			shoopgr() { //个人购买
				this.$axios.get("/user/query").then((res) => {
					if(res.data.code == 0) {
						this.$router.push({
							name: 'Personage',
							query: {
								id: this.id
							}
						})
					}
				})
			}
		},
		mounted() {
			this.$axios.get("/checkupPlan/details?planId=" + this.id).then((res) => {
				if(res.data.code == 0) {
					this.xiangqing = res.data.data;
					console.log(res.data.data)
				}
			})
		}
	}
</script>

<style>
	.ehg {
		width: 90%;
		margin: 0 auto 0.1rem;
	}
	
	.wvs {
		width: 100%;
		background: #fff;
		line-height: 0.3rem;
	}
	
	.money {
		display: flex;
		flex-direction: row;
		width: 45%;
	}
	
	.mian {
		width: 100%;
		display: flex;
		flex-direction: row;
		text-align: center;
		align-items: center;
		background: #fff;
		justify-content: center;
		padding: 0.1rem 0;
	}
	
	.kjh {
		width: 0.35rem;
		height: 0.4rem;
		margin: 0 auto;
	}
	
	.mian>div {
		width: 33.3%;
	}
	
	.taocanx {
		width: 100%;
		background: #fff;
		margin-top: 0.06rem;
	}
	
	.mun>div {
		padding: 0.05rem 0;
	}
	
	.touh {
		background: #f6f6f6;
		padding: 0.02rem 0;
		text-align: center;
		color: #999999;
	}
	
	.xiangm {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		color: #a1a1a1;
		border-bottom: 0.01rem solid #e5e5e5;
	}
	
	.footer {
		width: 100%;
		height: 0.4rem;
		line-height: 0.4rem;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		position: fixed;
		bottom: 0;
	}
	
	.footer>div {
		width: 50%;
		text-align: center;
		color: #fff;
	}
</style>