// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import './assets/css/style.css' /*引入公共样式*/
import { Lazyload } from 'vant';
import './assets/js/rem.js'
import VueDirectiveImagePreviewer from 'vue-directive-image-previewer'
import 'vue-directive-image-previewer/dist/assets/style.css'

Vue.use(VueDirectiveImagePreviewer)
Vue.use(Lazyload);
Vue.config.productionTip = false

import axios from 'axios'
axios.defaults.withCredentials = true
Vue.prototype.$axios = axios;
Vue.prototype.baseURL = process.env.API_ROOT;

import './http.js'

router.afterEach(() => {
	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;
})

/* eslint-disable no-new */
new Vue({
	el: '#app',
	router,
	components: {
		App
	},
	template: '<App/>'
})
