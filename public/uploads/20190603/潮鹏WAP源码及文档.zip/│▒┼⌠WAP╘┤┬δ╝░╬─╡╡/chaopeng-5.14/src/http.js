import axios from 'axios'
import { Toast } from 'vant';
import router from './router'
// 设置超时时间
axios.default.timeout = 5000
// 请求前
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
axios.defaults.withCredentials = true
axios.defaults.baseURL = 'https://www.chaopengjiankang.com/api'
axios.interceptors.request.use(config => {
	config.headers = {
		'Content-Type': 'application/json', // 设置很关键
	}
	Toast.loading({
		mask: false,
		duration:5000,
		message: '加载中...'
	});
  return config
}, error => {
  Toast('加载超时')
  return Promise.reject(error)
})
// 请求后
axios.interceptors.response.use(data => {
  // 响应成功关闭
	Toast.clear()
  	const code = data.data.code;
  	if(code==501){
  		localStorage.removeItem("phone")
  		router.replace({
			name: 'login',
			query: {redirect: router.currentRoute.fullPath} //登录后再跳回此页面时要做的配置
		})
  	}
	if(code==-1){
		Toast(data.data.msg)
	}
  return data
}, error => {
  Toast('加载失败')
  return Promise.reject(error)
})

export default axios
